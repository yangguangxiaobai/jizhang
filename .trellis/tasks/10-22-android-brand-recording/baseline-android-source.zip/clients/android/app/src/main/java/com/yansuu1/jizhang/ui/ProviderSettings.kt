package com.yansuu1.jizhang.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yansuu1.jizhang.net.ApiClient
import com.yansuu1.jizhang.net.AuthExpiredException
import com.yansuu1.jizhang.repo.AssistantRepository
import com.yansuu1.jizhang.ui.theme.LocalWebTokens
import kotlinx.coroutines.launch
import org.json.JSONObject

private data class ProviderDraft(
    val enabled: Boolean = false,
    val mode: String = "chat-completions",
    val method: String = "POST",
    val authKind: String = "bearer",
    val name: String = "",
    val url: String = "",
    val model: String = "",
    val timeoutMs: String = "20000",
    val headers: String = "{}",
    val bodyTemplate: String = "",
    val responsePath: String = "choices[0].message.content",
    val headerName: String = "",
)

@Composable
fun ProviderSettings(api: ApiClient, onAuthExpired: () -> Unit) {
    val repo = remember(api) { AssistantRepository(api) }
    val scope = rememberCoroutineScope()
    val t = LocalWebTokens.current
    val motion = LocalMotionTokens.current
    val revealDistancePx = with(LocalDensity.current) { 8.dp.roundToPx() }

    var draft by remember { mutableStateOf(ProviderDraft()) }
    var savedDraft by remember { mutableStateOf<ProviderDraft?>(null) }
    // Secrets intentionally stay in ordinary in-memory Compose state only.
    var secret by remember { mutableStateOf("") }
    var hasSecret by remember { mutableStateOf(false) }
    var clearSecret by remember { mutableStateOf(false) }
    var bodyTemplateUnavailable by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var operation by remember { mutableStateOf<String?>(null) }
    var advancedExpanded by remember { mutableStateOf(false) }
    var clearDialog by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var statusIsError by remember { mutableStateOf(false) }
    var timeoutError by remember { mutableStateOf<String?>(null) }
    var headersError by remember { mutableStateOf<String?>(null) }

    val hasUnsavedChanges = loaded && (
        draft != savedDraft || secret.isNotEmpty() || clearSecret
    )
    val fieldsEnabled = loaded && operation == null

    suspend fun loadConfiguration() {
        loading = true
        try {
            val config = repo.providerConfig()
            val auth = config.optJSONObject("auth")
            val loadedDraft = ProviderDraft(
                enabled = config.optBoolean("enabled"),
                mode = config.optString("mode", "chat-completions"),
                method = config.optString("method", "POST"),
                authKind = auth?.optString("kind", "bearer") ?: "bearer",
                name = config.optString("name"),
                url = config.optString("url"),
                model = config.optString("model"),
                timeoutMs = config.optInt("timeoutMs", 20_000).toString(),
                headers = config.optJSONObject("headers")?.toString(2) ?: "{}",
                bodyTemplate = if (config.isNull("bodyTemplate")) "" else config.optString("bodyTemplate"),
                responsePath = config.optString("responsePath", "choices[0].message.content"),
                headerName = auth?.optString("headerName").orEmpty(),
            )
            draft = loadedDraft
            savedDraft = loadedDraft
            bodyTemplateUnavailable = loadedDraft.mode != "custom" && config.isNull("bodyTemplate")
            hasSecret = config.optBoolean("hasSecret")
            secret = ""
            clearSecret = false
            timeoutError = null
            headersError = null
            statusMessage = null
            loaded = true
        } catch (e: AuthExpiredException) {
            statusMessage = "登录状态已过期，请重新登录。"
            statusIsError = true
            onAuthExpired()
        } catch (e: Exception) {
            statusMessage = e.message ?: "无法读取 AI 配置，请重试。"
            statusIsError = true
        } finally {
            loading = false
        }
    }

    LaunchedEffect(repo) { loadConfiguration() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (loading && !loaded) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                CircularProgressIndicator(color = t.accent)
                Spacer(Modifier.height(12.dp))
                Text("正在读取 AI 配置…", color = t.muted)
            }
        } else if (!loaded) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
                    .padding(top = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                ProviderNotice(statusMessage ?: "配置加载失败，当前不能保存空配置。", isError = true)
                OutlinedButton(
                    enabled = !loading,
                    onClick = { scope.launch { loadConfiguration() } },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, t.accent.copy(alpha = 0.5f)),
                ) {
                    Text(if (loading) "正在重试…" else "重新加载配置", color = t.accent)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(top = 4.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // ==========================================
                // [Card 1] 服务状态与主开关
                // ==========================================
                JzCard(Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Text(
                                    "AI 助理服务",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                val pillBg = if (draft.enabled) t.ok.copy(alpha = 0.12f) else t.muted.copy(alpha = 0.12f)
                                val pillFg = if (draft.enabled) t.ok else t.muted
                                val pillText = if (draft.enabled) "已启用" else "未启用"
                                Box(
                                    modifier = Modifier
                                        .background(pillBg, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(pillFg, CircleShape),
                                        )
                                        Text(
                                            pillText,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = pillFg,
                                        )
                                    }
                                }
                            }
                            Text(
                                if (draft.enabled) "已启用 · 记账会话与账单解析可正常调用模型"
                                else "未启用 · 关闭后 AI 助理功能将暂停模型调用",
                                style = MaterialTheme.typography.bodySmall,
                                color = t.muted,
                            )
                        }
                        Switch(
                            checked = draft.enabled,
                            enabled = fieldsEnabled,
                            onCheckedChange = { draft = draft.copy(enabled = it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = t.surface,
                                checkedTrackColor = t.accent,
                                uncheckedThumbColor = t.surface,
                                uncheckedTrackColor = t.border,
                            ),
                        )
                    }
                }

                // ==========================================
                // [Card 2] 核心配置 (New API / OpenAI 极简三要素)
                // ==========================================
                JzCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = t.accent,
                                modifier = Modifier.size(20.dp),
                            )
                            Column {
                                Text(
                                    "核心配置 (New API / OpenAI 兼容)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    "重点支持自建 New API、One API 及通用 OpenAI 兼容服务",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = t.muted,
                                )
                            }
                        }

                        // 配置名称 (可选)
                        ProviderTextField(
                            value = draft.name,
                            onValueChange = { draft = draft.copy(name = it) },
                            label = "配置名称（可选）",
                            placeholder = "例如：自建 New API / DeepSeek",
                            enabled = fieldsEnabled,
                            singleLine = true,
                        )

                        // 服务地址 (Base URL)
                        val normalizedPreview = remember(draft.url, draft.mode) {
                            ProviderSettingsHelper.normalizeUrl(draft.url, draft.mode)
                        }
                        val urlSupportingText = when {
                            draft.url.isNotBlank() && normalizedPreview != draft.url.trim() && draft.mode == "chat-completions" ->
                                "💡 保存时将自动补全为: $normalizedPreview"
                            else -> "支持直接粘贴中转站根域名，保存时自动补全 /v1/chat/completions"
                        }
                        ProviderTextField(
                            value = draft.url,
                            onValueChange = { draft = draft.copy(url = it) },
                            label = "服务地址 (Base URL)",
                            placeholder = "https://api.my-domain.com",
                            enabled = fieldsEnabled,
                            singleLine = true,
                            keyboardType = KeyboardType.Uri,
                            supportingText = urlSupportingText,
                        )

                        // API 密钥 (API Key)
                        val secretSupportingText = when {
                            secret.isNotEmpty() -> "已输入新密钥（将在保存时发送至服务器）"
                            hasSecret && !clearSecret && draft.authKind == "none" -> "服务器已保存密钥；当前认证方式为“无”，不会使用此密钥"
                            hasSecret && !clearSecret -> "服务器已保存密钥；已加密存储（留空保持不变）"
                            clearSecret -> "已标记清除；保存配置后才生效"
                            draft.authKind == "none" -> "当前认证方式不使用密钥"
                            else -> "尚未保存密钥"
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            ProviderTextField(
                                value = secret,
                                onValueChange = {
                                    secret = it
                                    if (it.isNotEmpty()) clearSecret = false
                                },
                                label = "API 密钥 (API Key)",
                                placeholder = if (hasSecret && !clearSecret) "已保存密钥（留空不改）" else "sk-...",
                                enabled = fieldsEnabled,
                                singleLine = true,
                                isPassword = true,
                                keyboardType = KeyboardType.Password,
                                supportingText = secretSupportingText,
                            )

                            if (hasSecret && !clearSecret) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                ) {
                                    TextButton(
                                        enabled = fieldsEnabled,
                                        onClick = { clearDialog = true },
                                    ) {
                                        Text("清除已保存密钥…", color = t.danger, fontSize = 13.sp)
                                    }
                                }
                            } else if (clearSecret) {
                                Surface(
                                    color = t.dangerSubtle,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, t.danger.copy(alpha = 0.35f)),
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Text(
                                            "已标记清除。保存后将无法使用原密钥。",
                                            modifier = Modifier.weight(1f),
                                            color = t.danger,
                                            style = MaterialTheme.typography.bodySmall,
                                        )
                                        TextButton(
                                            enabled = fieldsEnabled,
                                            onClick = { clearSecret = false },
                                        ) {
                                            Text("撤销", color = t.accent)
                                        }
                                    }
                                }
                            }
                        }

                        // 模型名称 (Model)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            ProviderTextField(
                                value = draft.model,
                                onValueChange = { draft = draft.copy(model = it) },
                                label = "模型名称 (Model)",
                                placeholder = "如 gpt-4o-mini 或 deepseek-chat",
                                enabled = fieldsEnabled,
                                singleLine = true,
                                supportingText = "输入模型名称或点按下方快捷填入",
                            )

                            Text(
                                "常用模型（点击一键填入）：",
                                style = MaterialTheme.typography.labelSmall,
                                color = t.muted,
                                modifier = Modifier.padding(top = 2.dp),
                            )
                            @OptIn(ExperimentalLayoutApi::class)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                ProviderSettingsHelper.POPULAR_MODELS.forEach { modelName ->
                                    val isSelected = draft.model.trim() == modelName
                                    FilterChip(
                                        selected = isSelected,
                                        enabled = fieldsEnabled,
                                        onClick = { draft = draft.copy(model = modelName) },
                                        label = {
                                            Text(
                                                modelName,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                            )
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = t.accentSubtle,
                                            selectedLabelColor = t.accent,
                                            containerColor = t.surfaceSoft.copy(alpha = 0.6f),
                                            labelColor = t.fg,
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            enabled = fieldsEnabled,
                                            selected = isSelected,
                                            borderColor = if (isSelected) t.accent else t.border.copy(alpha = 0.65f),
                                        ),
                                    )
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // [Card 3] 连通性测试与配置保存 (主操作区)
                // ==========================================
                JzCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = t.accent,
                                modifier = Modifier.size(20.dp),
                            )
                            Column {
                                Text(
                                    "保存与连通性测试",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    "保存将配置写入服务器；测试直接检验中转连接与模型响应",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = t.muted,
                                )
                            }
                        }

                        if (hasUnsavedChanges) {
                            ProviderNotice(
                                "有未保存修改。测试操作只针对服务器上已保存的配置，请先保存。",
                                isError = false,
                                isWarning = true,
                            )
                        }
                        statusMessage?.let { msg ->
                            ProviderNotice(msg, isError = statusIsError)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Button(
                                enabled = fieldsEnabled,
                                onClick = {
                                    val timeout = draft.timeoutMs.trim().toIntOrNull()
                                    if (timeout == null || timeout !in 3_000..60_000) {
                                        timeoutError = "请输入 3000 到 60000 之间的整数毫秒。"
                                        advancedExpanded = true
                                        return@Button
                                    }
                                    val parsedHeaders = try {
                                        JSONObject(draft.headers)
                                    } catch (_: Exception) {
                                        headersError = "请求头必须是有效的 JSON 对象。"
                                        advancedExpanded = true
                                        return@Button
                                    }
                                    if (draft.authKind == "header" && draft.headerName.isBlank()) {
                                        advancedExpanded = true
                                        statusMessage = "请填写自定义认证请求头名称。"
                                        statusIsError = true
                                        return@Button
                                    }

                                    // 智能规范化 URL 自动补齐 /v1/chat/completions
                                    val normalizedUrl = ProviderSettingsHelper.normalizeUrl(draft.url, draft.mode)
                                    val actualDraft = draft.copy(url = normalizedUrl)
                                    draft = actualDraft

                                    scope.launch {
                                        operation = "save"
                                        statusMessage = null
                                        statusIsError = false
                                        try {
                                            val input = mutableMapOf<String, Any?>(
                                                "enabled" to actualDraft.enabled,
                                                "mode" to actualDraft.mode,
                                                "method" to actualDraft.method,
                                                "name" to actualDraft.name,
                                                "url" to normalizedUrl,
                                                "model" to actualDraft.model,
                                                "timeoutMs" to timeout,
                                                "headers" to parsedHeaders,
                                                "auth" to JSONObject().put("kind", actualDraft.authKind).apply {
                                                    if (actualDraft.authKind == "header") put("headerName", actualDraft.headerName)
                                                },
                                                "responsePath" to actualDraft.responsePath,
                                                "clearSecret" to clearSecret,
                                            )
                                            if (!bodyTemplateUnavailable) {
                                                input["bodyTemplate"] = actualDraft.bodyTemplate.takeIf { it.isNotBlank() }
                                            }
                                            if (secret.isNotEmpty()) input["secret"] = secret
                                            val saved = repo.saveProviderConfig(input)
                                            hasSecret = saved.optBoolean(
                                                "hasSecret",
                                                when {
                                                    clearSecret -> false
                                                    secret.isNotEmpty() -> true
                                                    else -> hasSecret
                                                },
                                            )
                                            secret = ""
                                            clearSecret = false
                                            if (actualDraft.mode == "custom" && !saved.isNull("bodyTemplate")) {
                                                draft = actualDraft.copy(bodyTemplate = saved.optString("bodyTemplate"))
                                                bodyTemplateUnavailable = false
                                            } else if (actualDraft.mode != "custom" && saved.isNull("bodyTemplate")) {
                                                bodyTemplateUnavailable = actualDraft.bodyTemplate.isBlank()
                                            }
                                            savedDraft = draft
                                            statusMessage = "配置已保存。测试将使用这份已保存配置。"
                                            statusIsError = false
                                        } catch (e: AuthExpiredException) {
                                            statusMessage = "登录状态已过期，请重新登录。"
                                            statusIsError = true
                                            onAuthExpired()
                                        } catch (e: Exception) {
                                            statusMessage = e.message ?: "保存失败，请检查配置后重试。"
                                            statusIsError = true
                                        } finally {
                                            operation = null
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = t.accent,
                                    contentColor = t.onAccent,
                                ),
                            ) {
                                if (operation == "save") {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = t.onAccent,
                                        strokeWidth = 2.dp,
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text("正在保存…")
                                } else {
                                    Text("保存配置", fontWeight = FontWeight.SemiBold)
                                }
                            }

                            OutlinedButton(
                                enabled = fieldsEnabled && !hasUnsavedChanges,
                                onClick = {
                                    if (hasUnsavedChanges) {
                                        statusMessage = "请先保存修改；测试只会调用服务器上已保存的配置。"
                                        statusIsError = false
                                        return@OutlinedButton
                                    }
                                    scope.launch {
                                        operation = "test"
                                        statusMessage = "正在测试连接…"
                                        statusIsError = false
                                        val start = System.currentTimeMillis()
                                        try {
                                            repo.testProvider()
                                            val duration = System.currentTimeMillis() - start
                                            statusMessage = "连通性测试通过 (耗时 ${duration}ms)"
                                            statusIsError = false
                                        } catch (e: AuthExpiredException) {
                                            statusMessage = "登录状态已过期，请重新登录。"
                                            statusIsError = true
                                            onAuthExpired()
                                        } catch (e: Exception) {
                                            statusMessage = e.message ?: "测试失败，请检查已保存配置。"
                                            statusIsError = true
                                        } finally {
                                            operation = null
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (fieldsEnabled && !hasUnsavedChanges) t.accent.copy(alpha = 0.5f) else t.border.copy(alpha = 0.3f),
                                ),
                            ) {
                                if (operation == "test") {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = t.accent,
                                        strokeWidth = 2.dp,
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text("正在测试…")
                                } else {
                                    Text(
                                        "测试连接",
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (fieldsEnabled && !hasUnsavedChanges) t.accent else t.muted,
                                    )
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // [Card 4] 高级请求设置 (折叠收拢)
                // ==========================================
                JzCard(Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { advancedExpanded = !advancedExpanded }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Tune,
                                    contentDescription = null,
                                    tint = t.muted,
                                    modifier = Modifier.size(20.dp),
                                )
                                Column {
                                    Text(
                                        "高级请求设置",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                    Text(
                                        "模式、认证头、自定义 JSON 与超时",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = t.muted,
                                    )
                                }
                            }
                            IconButton(
                                onClick = { advancedExpanded = !advancedExpanded },
                                enabled = loaded,
                            ) {
                                Icon(
                                    imageVector = if (advancedExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                    contentDescription = if (advancedExpanded) "收起高级设置" else "展开高级设置",
                                    tint = t.muted,
                                )
                            }
                        }

                        AnimatedVisibility(
                            visible = advancedExpanded,
                            enter = if (motion.reduced) EnterTransition.None else
                                fadeIn(tween(motion.baseMillis, easing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f))) +
                                    slideInVertically(
                                        animationSpec = tween(motion.baseMillis, easing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)),
                                        initialOffsetY = { -it.coerceAtMost(revealDistancePx) },
                                    ),
                            exit = if (motion.reduced) ExitTransition.None else
                                fadeOut(tween(motion.quickMillis)) +
                                    slideOutVertically(
                                        animationSpec = tween(motion.quickMillis),
                                        targetOffsetY = { -it.coerceAtMost(revealDistancePx) },
                                    ),
                        ) {
                            Column(
                                modifier = Modifier.padding(top = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                // 接口模式
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("接口模式", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf(
                                            "chat-completions" to "Chat",
                                            "responses" to "Responses",
                                            "custom" to "自定义",
                                        ).forEach { (value, label) ->
                                            val isSelected = draft.mode == value
                                            FilterChip(
                                                selected = isSelected,
                                                enabled = fieldsEnabled,
                                                onClick = { draft = draft.copy(mode = value) },
                                                label = { Text(label, fontSize = 12.sp) },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp),
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = t.accentSubtle,
                                                    selectedLabelColor = t.accent,
                                                ),
                                            )
                                        }
                                    }
                                    Text(
                                        when (draft.mode) {
                                            "responses" -> "Responses 模式。切换模式不会改写响应路径或自定义模板。"
                                            "custom" -> "自定义模式可设置请求方式、请求头、请求体模板与响应路径。"
                                            else -> "Chat Completions 模式。切换模式不会改写已填写的高级字段。"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = t.muted,
                                    )
                                }

                                // 认证方式
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("认证方式", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf("bearer" to "Bearer", "header" to "自定义头", "none" to "无认证")
                                            .forEach { (value, label) ->
                                                val isSelected = draft.authKind == value
                                                FilterChip(
                                                    selected = isSelected,
                                                    enabled = fieldsEnabled,
                                                    onClick = { draft = draft.copy(authKind = value) },
                                                    label = { Text(label, fontSize = 12.sp) },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = t.accentSubtle,
                                                        selectedLabelColor = t.accent,
                                                    ),
                                                )
                                            }
                                    }
                                    if (draft.authKind == "header") {
                                        ProviderTextField(
                                            value = draft.headerName,
                                            onValueChange = { draft = draft.copy(headerName = it) },
                                            label = "自定义认证请求头名称",
                                            placeholder = "例如 X-API-Key",
                                            enabled = fieldsEnabled,
                                            singleLine = true,
                                        )
                                    }
                                }

                                // HTTP 请求方式
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("HTTP 请求方式", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        listOf("GET", "POST", "PUT", "PATCH").forEach { value ->
                                            val isSelected = draft.method == value
                                            FilterChip(
                                                selected = isSelected,
                                                enabled = fieldsEnabled,
                                                onClick = { draft = draft.copy(method = value) },
                                                label = { Text(value, fontSize = 12.sp) },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp),
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = t.accentSubtle,
                                                    selectedLabelColor = t.accent,
                                                ),
                                            )
                                        }
                                    }
                                }

                                // 超时时间
                                ProviderTextField(
                                    value = draft.timeoutMs,
                                    onValueChange = {
                                        draft = draft.copy(timeoutMs = it)
                                        timeoutError = null
                                    },
                                    label = "超时时间 (毫秒)",
                                    placeholder = "20000",
                                    enabled = fieldsEnabled,
                                    singleLine = true,
                                    keyboardType = KeyboardType.Number,
                                    supportingText = timeoutError ?: "请输入 3000 到 60000 之间的整数毫秒",
                                    isError = timeoutError != null,
                                )

                                // 额外请求头
                                ProviderTextField(
                                    value = draft.headers,
                                    onValueChange = {
                                        draft = draft.copy(headers = it)
                                        headersError = null
                                    },
                                    label = "额外请求头 JSON",
                                    placeholder = "{}",
                                    enabled = fieldsEnabled,
                                    minLines = 3,
                                    maxLines = 7,
                                    supportingText = headersError ?: "敏感认证头请在上方认证方式中配置",
                                    isError = headersError != null,
                                )

                                // 自定义请求体模板
                                ProviderTextField(
                                    value = draft.bodyTemplate,
                                    onValueChange = {
                                        draft = draft.copy(bodyTemplate = it)
                                        bodyTemplateUnavailable = false
                                    },
                                    label = "自定义请求体模板（留空使用模式默认值）",
                                    placeholder = "留空使用默认模板",
                                    enabled = fieldsEnabled,
                                    minLines = 4,
                                    maxLines = 10,
                                    supportingText = "模板变量由服务器校验；不能在模板中引用密钥。",
                                )
                                if (bodyTemplateUnavailable && draft.bodyTemplate.isBlank()) {
                                    ProviderNotice(
                                        "现有接口在已保存模式不是 custom 时不会返回 bodyTemplate。此处留空表示当前不可读取，不表示服务器已清空；未明确编辑此字段时，保存其它设置会保留服务器原值。",
                                        isError = false,
                                    )
                                }

                                // 响应内容路径
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    ProviderTextField(
                                        value = draft.responsePath,
                                        onValueChange = { draft = draft.copy(responsePath = it) },
                                        label = "响应内容路径",
                                        placeholder = "choices[0].message.content",
                                        enabled = fieldsEnabled,
                                        singleLine = true,
                                    )
                                    if (draft.mode != "custom") {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                            TextButton(
                                                enabled = fieldsEnabled,
                                                onClick = {
                                                    draft = draft.copy(responsePath = defaultResponsePath(draft.mode))
                                                },
                                            ) {
                                                Text("填入当前模式常用路径", color = t.accent, fontSize = 13.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (clearDialog) {
        AlertDialog(
            onDismissRequest = { clearDialog = false },
            title = { Text("清除已保存密钥？") },
            text = {
                Text("确认后会先标记清除；只有保存配置后才会从服务器移除密钥。清除后，使用该密钥的认证请求将无法连接。")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        secret = ""
                        clearSecret = true
                        statusMessage = null
                        clearDialog = false
                    },
                ) { Text("标记清除", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { clearDialog = false }) { Text("返回") }
            },
        )
    }
}

@Composable
private fun ProviderTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    placeholder: String? = null,
    singleLine: Boolean = false,
    minLines: Int = 1,
    maxLines: Int = if (singleLine) 1 else 4,
    isPassword: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    supportingText: String? = null,
    isError: Boolean = false,
) {
    val t = LocalWebTokens.current
    var passwordVisible by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = placeholder?.let { { Text(it, color = t.muted.copy(alpha = 0.6f)) } },
        modifier = modifier.fillMaxWidth(),
        enabled = enabled,
        singleLine = singleLine,
        minLines = minLines,
        maxLines = maxLines,
        shape = RoundedCornerShape(12.dp),
        visualTransformation = if (isPassword && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        trailingIcon = if (isPassword) {
            {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (passwordVisible) "隐藏密码" else "显示密码",
                        tint = t.muted,
                    )
                }
            }
        } else null,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = t.surface,
            unfocusedContainerColor = t.surfaceSoft.copy(alpha = 0.5f),
            disabledContainerColor = t.surfaceSoft.copy(alpha = 0.25f),
            focusedBorderColor = t.accent,
            unfocusedBorderColor = t.border.copy(alpha = 0.65f),
            disabledBorderColor = t.border.copy(alpha = 0.35f),
            focusedLabelColor = t.accent,
            cursorColor = t.accent,
        ),
        isError = isError,
        supportingText = supportingText?.let { valueText ->
            { Text(valueText, style = MaterialTheme.typography.bodySmall) }
        },
    )
}

@Composable
private fun ProviderNotice(
    message: String,
    isError: Boolean,
    isWarning: Boolean = false,
) {
    val t = LocalWebTokens.current
    val bg = when {
        isError -> t.dangerSubtle
        isWarning -> Color(0xFFFEF3C7)
        else -> t.accentSubtle
    }
    val fg = when {
        isError -> t.danger
        isWarning -> Color(0xFF92400E)
        else -> t.accent
    }
    val borderCol = when {
        isError -> t.danger.copy(alpha = 0.35f)
        isWarning -> Color(0xFFF59E0B).copy(alpha = 0.4f)
        else -> t.accent.copy(alpha = 0.35f)
    }
    val icon = when {
        isError -> Icons.Filled.Warning
        isWarning -> Icons.Filled.Info
        else -> Icons.Filled.CheckCircle
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = bg,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, borderCol),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(18.dp),
            )
            Text(
                message,
                modifier = Modifier.weight(1f),
                color = fg,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

private fun defaultResponsePath(mode: String): String = when (mode) {
    "responses" -> "output_text"
    "chat-completions" -> "choices[0].message.content"
    else -> ""
}
