package com.yansuu1.jizhang.ui

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EventRepeat
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.yansuu1.jizhang.net.ApiClient
import com.yansuu1.jizhang.repo.AuthRepository
import com.yansuu1.jizhang.ui.theme.AccentPreset
import com.yansuu1.jizhang.ui.theme.ThemePreference
import com.yansuu1.jizhang.ui.theme.LocalWebTokens
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

private val THEME_KEY = stringPreferencesKey("theme_preference")
private val ACCENT_KEY = stringPreferencesKey("accent_preset")

/**
 * 我的 tab (A2+A7+A10): settings hub. Mirrors web `SettingsView` + `DataView` entry
 * points: each section swaps inline (single-activity shell, no deep-link router).
 * Trash / transfers / templates / recurring-rules / manage / items / settings
 * all live here, matching Web where they hang off 我的 (nav:'settings').
 *
 * NOTE: AI 聊天已提升为底部一级入口；此处仅保留 AI 接口设置。
 */
@Composable
fun MyTab(
    api: ApiClient,
    auth: AuthRepository? = null,
    theme: ThemePreference,
    accent: AccentPreset,
    onTheme: (ThemePreference) -> Unit,
    onAccent: (AccentPreset) -> Unit,
    reduceMotion: Boolean = false,
    onReduceMotion: (Boolean) -> Unit = {},
    initialSection: String? = null,
    onAuthExpired: () -> Unit,
    onLoggedOut: () -> Unit = {},
    onSubpageChange: (Boolean) -> Unit = {},
) {
    var section by remember { mutableStateOf("home") }
    fun closeSection() {
        section = "home"
        onSubpageChange(false)
    }
    fun openSection(key: String) {
        section = key
        onSubpageChange(true)
    }
    LaunchedEffect(initialSection) {
        if (initialSection != null) openSection(initialSection)
    }
    BackHandler(section != "home") { closeSection() }
    if (section != "home") {
        Column(Modifier.fillMaxSize()) {
            if (section != "salary") {
                Row(
                    modifier = Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { closeSection() }) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "返回我的",
                        )
                    }
                    Text(sectionTitle(section), style = MaterialTheme.typography.titleLarge)
                }
            }
            when (section) {
                "manage" -> ManageTab(api = api, onAuthExpired = onAuthExpired)
                "templates" -> TemplatesTab(api = api, onAuthExpired = onAuthExpired)
                "recurring" -> RecurringRulesTab(api = api, onAuthExpired = onAuthExpired)
                "transfers" -> TransfersTab(api = api, onAuthExpired = onAuthExpired)
                "trash" -> TrashTab(api = api, onAuthExpired = onAuthExpired)
                "data" -> DataTab(api = api, onAuthExpired = onAuthExpired)
                "items" -> ItemsTab(api = api, onAuthExpired = onAuthExpired)
                "assistant" -> AssistantTab(api = api, onAuthExpired = onAuthExpired)
                "provider" -> ProviderSettings(api = api, onAuthExpired = onAuthExpired)
                "pending" -> PendingTab(api = api, onAuthExpired = onAuthExpired)
                "salary" -> SalarySheet(api = api, onAuthExpired = onAuthExpired, onSaved = {}, onClose = { closeSection() })
                "settings" -> SettingsFull(
                    api = api,
                    auth = auth,
                    theme = theme,
                    accent = accent,
                    onTheme = onTheme,
                    onAccent = onAccent,
                    reduceMotion = reduceMotion,
                    onReduceMotion = onReduceMotion,
                    onLoggedOut = onLoggedOut,
                )
            }
        }
        return
    }
    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Profile & User Header (1:1 复刻设计图：右上角齿轮 + 圆形可爱头像 + 记账用户 + 管理个人设置)
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "我的",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = LocalWebTokens.current.fg,
                )
                IconButton(
                    onClick = { openSection("settings") },
                    modifier = Modifier.size(36.dp),
                ) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = "设置",
                        tint = LocalWebTokens.current.fg,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
            FinanceCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 18.dp,
                contentPadding = 16.dp,
                onClick = { openSection("settings") },
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    FinanceUserAvatar(
                        name = auth?.username?.ifBlank { "记账用户" } ?: "记账用户",
                        sizeDp = 52.dp,
                    )
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            auth?.username?.ifBlank { "记账用户" } ?: "记账用户",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = LocalWebTokens.current.fg,
                        )
                        Text(
                            "管理个人设置",
                            style = MaterialTheme.typography.bodySmall,
                            color = LocalWebTokens.current.muted,
                        )
                    }
                    Text("›", style = MaterialTheme.typography.titleLarge, color = LocalWebTokens.current.muted)
                }
            }
            SettingsGroup(
                title = "账本管理",
                links = listOf(
                    SettingLink("salary", "工资记录", "查看工资与分配", Icons.Filled.AccountBalanceWallet, Color(0xFF4B7682)),
                    SettingLink("manage", "分类与账户", "管理分类、账户和标签", Icons.Filled.Category, Color(0xFF4B7682)),
                    SettingLink("templates", "分配模板", "设置周期预算分配比例", Icons.Filled.Description, Color(0xFF4B7682)),
                    SettingLink("recurring", "周期账单", "管理自动生成的待确认规则", Icons.Filled.EventRepeat, Color(0xFF4B7682)),
                    SettingLink("pending", "待确认账单", "核对周期规则生成的账单", Icons.Filled.PendingActions, Color(0xFF4B7682)),
                    SettingLink("transfers", "转账记录", "查看账户间转账记录", Icons.Filled.SwapHoriz, Color(0xFF4B7682)),
                    SettingLink("trash", "回收站", "恢复或彻底删除账单", Icons.Filled.DeleteOutline, Color(0xFF4B7682)),
                ),
                onSelect = { openSection(it) },
            )
            SettingsGroup(
                title = "数据与物品",
                links = listOf(
                    SettingLink("items", "物品资产", "查看物品、照片与使用成本", Icons.Filled.Inventory2, Color(0xFF4B7682)),
                    SettingLink("data", "数据管理", "导入、导出与服务端备份", Icons.Filled.Storage, Color(0xFF4B7682)),
                ),
                onSelect = { openSection(it) },
            )
            SettingsGroup(
                title = "设置与其他",
                links = listOf(
                    SettingLink("provider", "AI 接口设置", "管理模型与连接配置", Icons.Filled.Tune, Color(0xFF4B7682)),
                    SettingLink("settings", "外观与设置", "主题、周期起点和密码", Icons.Filled.Settings, Color(0xFF4B7682)),
                ),
                onSelect = { openSection(it) },
            )
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, LocalWebTokens.current.border),
            ) {
                SettingsTab(auth = auth, onLogout = onLoggedOut)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

private data class SettingLink(
    val key: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color(0xFF2D68FF),
)

@Composable
private fun SettingsGroup(title: String, links: List<SettingLink>, onSelect: (String) -> Unit) {
    val tokens = LocalWebTokens.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            color = tokens.fg,
        )
        FinanceCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 18.dp,
            contentPadding = 0.dp,
        ) {
            Column {
                links.forEachIndexed { index, link ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .clickable { onSelect(link.key) }
                            .padding(horizontal = 14.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(
                            modifier = Modifier.size(32.dp).background(link.color.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = androidx.compose.ui.Alignment.Center,
                        ) {
                            Icon(link.icon, contentDescription = null, tint = link.color, modifier = Modifier.size(17.dp))
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Text(
                                link.title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                                color = tokens.fg,
                            )
                        }
                        Text("›", style = MaterialTheme.typography.titleMedium, color = tokens.muted)
                    }
                    if (index < links.lastIndex) {
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 58.dp),
                            color = tokens.border.copy(alpha = 0.45f),
                        )
                    }
                }
            }
        }
    }
}

private fun sectionTitle(section: String): String = when (section) {
    "manage" -> "分类与账户"
    "templates" -> "分配模板"
    "recurring" -> "周期账单"
    "transfers" -> "转账"
    "trash" -> "回收站"
    "data" -> "数据管理"
    "items" -> "物品资产"
    "assistant" -> "AI 助理"
    "provider" -> "AI 接口设置"
    "pending" -> "待确认账单"
    "salary" -> "工资记录"
    "settings" -> "设置与外观"
    else -> "我的"
}

/** Read persisted theme prefs (called once from MainActivity). */
suspend fun readThemePrefs(context: Context): Pair<ThemePreference, AccentPreset> {
    return try {
        val p = context.appPrefs.data.first()
        val t = runCatching { ThemePreference.valueOf(p[THEME_KEY] ?: "System") }
            .getOrDefault(ThemePreference.System)
        val a = runCatching { AccentPreset.valueOf(p[ACCENT_KEY] ?: "Titanium") }
            .getOrDefault(AccentPreset.Titanium)
        t to a
    } catch (_: Exception) {
        ThemePreference.System to AccentPreset.Titanium
    }
}

/** Persist theme prefs (called from MainActivity callbacks). */
suspend fun writeThemePrefs(context: Context, theme: ThemePreference, accent: AccentPreset) {
    try {
        context.appPrefs.edit {
            it[THEME_KEY] = theme.name
            it[ACCENT_KEY] = accent.name
        }
    } catch (_: Exception) {
    }
}

/** Shared prefs accessor used by ApiClient-adjacent theme storage. */
val Context.appPrefs
    get() = com.yansuu1.jizhang.net.appPrefsOf(this)

/** Convenience: collect-once theme flow for previews/tests. */
fun themeLabels(): List<String> =
    ThemePreference.entries.map { it.label } + AccentPreset.entries.map { it.label }

@Suppress("UNUSED_PARAMETER")
fun consumeScope(scope: kotlinx.coroutines.CoroutineScope, block: () -> Unit = {}) {
    block()
}
