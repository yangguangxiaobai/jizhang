package com.yansuu1.jizhang.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.activity.compose.BackHandler
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.yansuu1.jizhang.net.ApiClient
import com.yansuu1.jizhang.repo.AuthRepository
import com.yansuu1.jizhang.ui.theme.AccentPreset
import com.yansuu1.jizhang.ui.theme.LocalWebTokens
import com.yansuu1.jizhang.ui.theme.ThemePreference

/**
 * Authenticated shell: 4 main navigation tabs + center record button (4+1):
 * 首页 / 账单 / ＋(记一笔) / AI 助手 / 我的.
 * 预算与统计作为首页快捷卡片以及我的二级功能进入。
 */
enum class Tab(val label: String, val icon: ImageVector) {
    Dashboard("首页", Icons.Filled.Home),
    Transactions("账单", Icons.Filled.Receipt),
    Assistant("AI 助手", Icons.Filled.SmartToy),
    Settings("我的", Icons.Filled.Person),
}

@Composable
fun MainShell(
    api: ApiClient,
    auth: AuthRepository? = null,
    theme: ThemePreference = ThemePreference.System,
    accent: AccentPreset = AccentPreset.Titanium,
    onTheme: (ThemePreference) -> Unit = {},
    onAccent: (AccentPreset) -> Unit = {},
    reduceMotion: Boolean = false,
    onReduceMotion: (Boolean) -> Unit = {},
    onLogout: () -> Unit,
    onAuthExpired: () -> Unit = onLogout,
) {
    var tab by remember { mutableStateOf(Tab.Dashboard) }
    var recordSource by remember { mutableStateOf(Tab.Dashboard) }
    var editingTx by remember { mutableStateOf<String?>(null) }
    var viewingTx by remember { mutableStateOf<String?>(null) }
    var detailSource by remember { mutableStateOf(Tab.Dashboard) }
    var creatingTx by remember { mutableStateOf(false) }
    var creatingSalary by remember { mutableStateOf(false) }
    var showingPending by remember { mutableStateOf(false) }
    var showingBudget by remember { mutableStateOf(false) }
    var showingStats by remember { mutableStateOf(false) }
    var showingAssistantSubpage by remember { mutableStateOf(false) }
    var showingMySubpage by remember { mutableStateOf(false) }
    var openMySection by remember { mutableStateOf<String?>(null) }

    fun openRecord(from: Tab) {
        recordSource = from
        creatingTx = true
        editingTx = null
    }
    fun openDetail(from: Tab, id: String) {
        detailSource = from
        recordSource = from
        viewingTx = id
    }
    fun openEdit(from: Tab, id: String) {
        recordSource = from
        editingTx = id
        viewingTx = null
        creatingTx = false
        if (from != Tab.Transactions) tab = Tab.Transactions
    }
    BackHandler(creatingSalary || showingPending || showingBudget || showingStats || tab != Tab.Dashboard) {
        when {
            showingPending -> showingPending = false
            showingBudget -> showingBudget = false
            showingStats -> showingStats = false
            creatingSalary -> creatingSalary = false
            tab != Tab.Dashboard -> tab = Tab.Dashboard
        }
    }

    val hideBottomBar = creatingTx || editingTx != null || viewingTx != null ||
        creatingSalary || showingPending || showingBudget || showingStats || showingMySubpage || (tab == Tab.Assistant && showingAssistantSubpage)
    Scaffold(
        containerColor = LocalWebTokens.current.bg,
        bottomBar = {
            if (!hideBottomBar) {
                Surface(
                    color = Color.White,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column {
                        HorizontalDivider(
                            color = Color(0xFFE7E4DC),
                            thickness = 1.dp,
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            // 1. 首页
                            NavigationBarTabItem(
                                selected = tab == Tab.Dashboard,
                                label = "首页",
                                icon = Icons.Filled.Home,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    showingPending = false
                                    showingBudget = false
                                    showingStats = false
                                    openMySection = null
                                    showingMySubpage = false
                                    tab = Tab.Dashboard
                                },
                            )

                            // 2. 账单
                            NavigationBarTabItem(
                                selected = tab == Tab.Transactions,
                                label = "账单",
                                icon = Icons.Filled.Receipt,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    showingPending = false
                                    showingBudget = false
                                    showingStats = false
                                    openMySection = null
                                    showingMySubpage = false
                                    tab = Tab.Transactions
                                },
                            )

                            // 3. 中间突出的加号「记一笔」按钮 (非持久Tab)
                            Box(
                                modifier = Modifier.weight(1f),
                                contentAlignment = Alignment.Center,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(LocalWebTokens.current.accent)
                                        .clickable { openRecord(tab) },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Add,
                                        contentDescription = "记一笔",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                            }

                            // 4. AI 助理
                            NavigationBarTabItem(
                                selected = tab == Tab.Assistant,
                                label = "AI 助手",
                                icon = Icons.Filled.SmartToy,
                                modifier = Modifier.weight(1f),
                                isAi = true,
                                onClick = {
                                    showingPending = false
                                    showingBudget = false
                                    showingStats = false
                                    openMySection = null
                                    showingMySubpage = false
                                    tab = Tab.Assistant
                                },
                            )

                            // 5. 我的
                            NavigationBarTabItem(
                                selected = tab == Tab.Settings,
                                label = "我的",
                                icon = Icons.Filled.Person,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    showingPending = false
                                    showingBudget = false
                                    showingStats = false
                                    openMySection = null
                                    showingMySubpage = false
                                    tab = Tab.Settings
                                },
                            )
                        }
                    }
                }
            }
        },
    ) { inner ->
        Column(
            modifier = Modifier.fillMaxSize().padding(inner),
        ) {
            if (viewingTx != null) {
                TransactionDetailScreen(
                    api = api,
                    transactionId = viewingTx!!,
                    onAuthExpired = onAuthExpired,
                    onBack = { viewingTx = null },
                    onEdit = {
                        val id = viewingTx
                        if (id != null) openEdit(detailSource, id)
                    },
                )
            } else if (creatingTx || editingTx != null) {
                TransactionEditSheet(
                    api = api,
                    editId = editingTx,
                    onAuthExpired = onAuthExpired,
                    onSaved = {
                        creatingTx = false
                        editingTx = null
                        tab = recordSource
                    },
                    onClose = {
                        creatingTx = false
                        editingTx = null
                        tab = recordSource
                    },
                )
            } else when (tab) {
                Tab.Dashboard -> when {
                    showingPending -> PendingTab(
                        api = api,
                        onAuthExpired = onAuthExpired,
                        showPageHeader = true,
                        onBack = { showingPending = false },
                    )
                    showingBudget -> if (creatingSalary) {
                        SalarySheet(
                            api = api,
                            onAuthExpired = onAuthExpired,
                            onSaved = {},
                            onClose = { creatingSalary = false },
                        )
                    } else {
                        BudgetTab(
                            api = api,
                            onAuthExpired = onAuthExpired,
                            onNewSalary = { creatingSalary = true },
                            onTemplates = {
                                openMySection = "templates"
                                showingBudget = false
                                tab = Tab.Settings
                            },
                            onBack = { showingBudget = false },
                        )
                    }
                    showingStats -> StatsTab(
                        api = api,
                        onAuthExpired = onAuthExpired,
                        onBack = { showingStats = false },
                    )
                    else -> DashboardTab(
                        api = api,
                        onAuthExpired = onAuthExpired,
                        onSeeAllTransactions = { tab = Tab.Transactions },
                        onNewTransaction = { openRecord(Tab.Dashboard) },
                        onOpenTransaction = { openDetail(Tab.Dashboard, it) },
                        onPending = { showingPending = true },
                        onOpenBudget = { showingBudget = true },
                        onOpenStats = { showingStats = true },
                    )
                }
                Tab.Transactions -> TransactionsTab(
                    api = api,
                    onAuthExpired = onAuthExpired,
                    onNew = { openRecord(Tab.Transactions) },
                    onEdit = { openEdit(Tab.Transactions, it) },
                    onOpen = { openDetail(Tab.Transactions, it) },
                )
                Tab.Assistant -> AssistantTab(
                    api = api, onAuthExpired = onAuthExpired,
                    onSecondaryScreen = { showingAssistantSubpage = it },
                    onProviderSettings = { openMySection = "provider"; tab = Tab.Settings },
                )
                Tab.Settings -> MyTab(
                    api = api,
                    auth = auth,
                    theme = theme,
                    accent = accent,
                    onTheme = onTheme,
                    onAccent = onAccent,
                    reduceMotion = reduceMotion,
                    onReduceMotion = onReduceMotion,
                    onAuthExpired = onAuthExpired,
                    onLoggedOut = onLogout,
                    initialSection = openMySection,
                    onSubpageChange = {
                        showingMySubpage = it
                        if (!it) openMySection = null
                    },
                )
            }
        }
    }
}

@Composable
private fun NavigationBarTabItem(
    selected: Boolean,
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    isAi: Boolean = false,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(width = 40.dp, height = 26.dp)
                .background(
                    if (selected) Color(0xFFE7F0F4) else Color.Transparent,
                    RoundedCornerShape(10.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (isAi) {
                FinanceAiSparkleIcon(
                    modifier = Modifier.size(19.dp),
                    primaryColor = if (selected) Color(0xFF2F6F8F) else Color(0xFF88939A),
                    accentColor = if (selected) Color(0xFF4B7682) else Color(0xFF88939A),
                )
            } else {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (selected) Color(0xFF2F6F8F) else Color(0xFF88939A),
                    modifier = Modifier.size(19.dp),
                )
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) Color(0xFF2F6F8F) else Color(0xFF88939A),
        )
    }
}

@Composable
private fun PlaceholderPage(text: String) {
    Column(modifier = Modifier.fillMaxSize().padding()) {
        Text(text)
    }
}
