package com.yansuu1.jizhang.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.AlertDialog
import com.yansuu1.jizhang.ui.theme.LocalWebTokens
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yansuu1.jizhang.net.ApiClient
import com.yansuu1.jizhang.net.AuthExpiredException
import com.yansuu1.jizhang.repo.LedgerRepository
import com.yansuu1.jizhang.repo.MetaRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.json.JSONObject

private data class TransactionDraftSnapshot(
    val type: Int,
    val amount: String,
    val categoryId: String,
    val accountId: String,
    val date: String,
    val note: String,
    val tags: String,
    val refundLinks: String,
    val isRefund: Boolean,
)

/** Create or edit a transaction while preserving the complete ledger payload. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionEditSheet(
    api: ApiClient,
    editId: String?,
    onAuthExpired: () -> Unit,
    onSaved: () -> Unit,
    onClose: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val ledger = remember(api) { LedgerRepository(api) }
    val meta = remember(api) { MetaRepository(api) }
    var type by remember { mutableStateOf(0) }
    var amountText by remember { mutableStateOf("") }
    var parsedPreview by remember { mutableStateOf<Long?>(null) }
    var categoryId by remember { mutableStateOf("") }
    var accountId by remember { mutableStateOf("") }
    var dateText by remember { mutableStateOf(todayInput()) }
    var datePickerVisible by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var tagsText by remember { mutableStateOf("") }
    var refundLinks by remember { mutableStateOf("") }
    var isRefund by remember { mutableStateOf(false) }
    var expenseCats by remember { mutableStateOf(listOf<JSONObject>()) }
    var incomeCats by remember { mutableStateOf(listOf<JSONObject>()) }
    var accounts by remember { mutableStateOf(listOf<JSONObject>()) }
    var loading by remember { mutableStateOf(true) }
    var formReady by remember { mutableStateOf(false) }
    var loadKey by remember { mutableStateOf(0) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var baseline by remember(editId) { mutableStateOf<TransactionDraftSnapshot?>(null) }
    var discardConfirmation by remember(editId) { mutableStateOf(false) }
    val currentDraft = TransactionDraftSnapshot(
        type = type,
        amount = amountText,
        categoryId = categoryId,
        accountId = accountId,
        date = dateText,
        note = note,
        tags = tagsText,
        refundLinks = refundLinks,
        isRefund = isRefund,
    )
    val hasUnsavedChanges = baseline != null && currentDraft != baseline
    val expenseParentIds = remember(expenseCats) { parentCategoryIds(expenseCats) }
    val incomeParentIds = remember(incomeCats) { parentCategoryIds(incomeCats) }
    val parsedCents = parseYuanToCents(amountText)

    fun requestClose() {
        if (saving) return
        if (formReady && hasUnsavedChanges) {
            discardConfirmation = true
        } else {
            onClose()
        }
    }

    fun firstSelectableId(cats: List<JSONObject>, parents: Set<String>): String =
        cats.firstOrNull { it.optString("id").isNotBlank() && it.optString("id") !in parents }
            ?.optString("id").orEmpty()
            .ifEmpty { cats.firstOrNull()?.optString("id").orEmpty() }

    BackHandler(enabled = true) { requestClose() }

    LaunchedEffect(editId, loadKey) {
        loading = true
        formReady = false
        baseline = null
        discardConfirmation = false
        error = null
        try {
            val cats = meta.categories().optJSONArray("items")
            val ex = mutableListOf<JSONObject>()
            val inc = mutableListOf<JSONObject>()
            for (i in 0 until (cats?.length() ?: 0)) {
                val c = cats?.optJSONObject(i) ?: continue
                if (c.optInt("type") == 1) inc.add(c) else ex.add(c)
            }
            val accs = meta.accounts().optJSONArray("items")
            val al = mutableListOf<JSONObject>()
            for (i in 0 until (accs?.length() ?: 0)) {
                accs?.optJSONObject(i)?.let { al.add(it) }
            }

            if (editId == null) {
                type = 0
                amountText = ""
                parsedPreview = null
                categoryId = firstSelectableId(ex, parentCategoryIds(ex))
                accountId = al.firstOrNull()?.optString("id").orEmpty()
                dateText = todayInput()
                note = ""
                tagsText = ""
                refundLinks = ""
                isRefund = false
            } else {
                val item = ledger.getTransaction(editId)
                type = item.optInt("type")
                amountText = formatYuan(item.optLong("amountCents"))
                parsedPreview = item.optLong("amountCents")
                categoryId = item.optString("categoryId")
                accountId = item.optString("accountId")
                dateText = toDateInput(item.optLong("date"))
                note = item.optString("note")
                isRefund = item.optBoolean("isRefund")
                val existingTags = item.optJSONArray("tags")
                tagsText = (0 until (existingTags?.length() ?: 0))
                    .joinToString(", ") { existingTags!!.getString(it) }
                val links = item.optJSONArray("refundLinkedTxIds")
                refundLinks = (0 until (links?.length() ?: 0))
                    .joinToString(",") { links!!.getString(it) }
            }
            expenseCats = ex
            incomeCats = inc
            accounts = al
            baseline = TransactionDraftSnapshot(
                type = type,
                amount = amountText,
                categoryId = categoryId,
                accountId = accountId,
                date = dateText,
                note = note,
                tags = tagsText,
                refundLinks = refundLinks,
                isRefund = isRefund,
            )
            formReady = true
        } catch (e: CancellationException) {
            throw e
        } catch (e: AuthExpiredException) {
            onAuthExpired()
        } catch (e: Exception) {
            error = e.message ?: "账单信息加载失败"
        } finally {
            loading = false
        }
    }

    if (!formReady) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(if (editId == null) "记一笔" else "编辑账单", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            if (loading) {
                CircularProgressIndicator()
                Text("正在加载分类和账户…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("账单信息没有完整加载，暂时不能保存。", color = MaterialTheme.colorScheme.onSurfaceVariant)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { requestClose() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("返回") }
                    Button(onClick = { loadKey++ }, modifier = Modifier.heightIn(min = 48.dp)) { Text("重试") }
                }
            }
        }
        return
    }

    val visibleCats = if (type == 1) incomeCats else expenseCats
    val visibleParents = if (type == 1) incomeParentIds else expenseParentIds

    Column(modifier = Modifier.fillMaxSize()) {
        // 顶部导航栏（1:1 对齐 Ardot 7:295：取消 + 居中标题 + 保存）
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                "取消",
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Medium,
                color = LocalWebTokens.current.accent,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { requestClose() }
                    .padding(horizontal = 4.dp, vertical = 4.dp),
            )
            Text(
                if (editId == null) "记一笔" else "编辑账单",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = LocalWebTokens.current.fg,
            )
            Text(
                if (saving) "保存中…" else "保存",
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (formReady && !saving) LocalWebTokens.current.accent else LocalWebTokens.current.muted,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(enabled = formReady && !saving) {
                        scope.launch {
                            val cents = parseYuanToCents(amountText)
                            if (cents == null || cents <= 0) {
                                error = "金额须为大于 0 的数字"
                                return@launch
                            }
                            if (categoryId.isEmpty() || accountId.isEmpty()) {
                                error = "请选择分类与账户"
                                return@launch
                            }
                            if (categoryId in visibleParents) {
                                error = "父分类不能直接记账，请选择子分类"
                                return@launch
                            }
                            saving = true
                            error = null
                            try {
                                val body = JSONObject()
                                    .put("type", type)
                                    .put("amountCents", cents)
                                    .put("categoryId", categoryId)
                                    .put("accountId", accountId)
                                    .put("date", fromDateInput(dateText))
                                    .put("note", note)
                                    .put("isRefund", type == 1 && isRefund)
                                    .put("tags", org.json.JSONArray(tagsText.split(',', '，').map { it.trim() }.filter { it.isNotEmpty() }))
                                    .put("refundLinkedTxIds", org.json.JSONArray(if (type == 1 && isRefund) refundLinks.split(',', '，').map { it.trim() }.filter { it.isNotEmpty() } else emptyList<String>()))
                                if (editId == null) ledger.createTransaction(jsonToMap(body))
                                else ledger.updateTransaction(editId, jsonToMap(body))
                                onSaved()
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: AuthExpiredException) {
                                onAuthExpired()
                            } catch (e: Exception) {
                                error = e.message ?: "保存失败"
                            } finally {
                                saving = false
                            }
                        }
                    }
                    .padding(horizontal = 4.dp, vertical = 4.dp),
            )
        }
        HorizontalDivider(color = Color(0xFFE7E4DC), thickness = 1.dp)

        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // 支出 / 收入 宽胶囊段控（1:1 对齐 Ardot 7:304：深海蓝选中 0xFF2F6F8F + 冰蓝未选 0xFFE8F1F4）
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(if (type == 0) LocalWebTokens.current.accent else Color(0xFFE8F1F4))
                        .clickable {
                            type = 0
                            categoryId = firstSelectableId(expenseCats, expenseParentIds)
                            isRefund = false
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "支出",
                        color = if (type == 0) Color.White else LocalWebTokens.current.accent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(if (type == 1) LocalWebTokens.current.accent else Color(0xFFE8F1F4))
                        .clickable {
                            type = 1
                            categoryId = firstSelectableId(incomeCats, incomeParentIds)
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "收入",
                        color = if (type == 1) Color.White else LocalWebTokens.current.accent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            // 金额展示大卡（1:1 对齐 Ardot 7:309：纯白卡片、金额标签、32sp 粗体数字、辅助文本）
            FinanceCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 18.dp,
                contentPadding = 18.dp,
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text("金额", fontSize = 11.sp, color = LocalWebTokens.current.muted)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        Text(
                            "¥",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = LocalWebTokens.current.fg,
                            modifier = Modifier.padding(end = 4.dp),
                        )
                        Text(
                            text = if (amountText.isBlank()) "0.00" else amountText,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = LocalWebTokens.current.fg,
                        )
                    }
                    Text("填写实际发生金额", fontSize = 11.sp, color = Color(0xFF88939A))
                }
            }

            // 分类网格
            CategoryGrid(
                items = visibleCats,
                parentIds = visibleParents,
                selected = categoryId,
                onSelect = { categoryId = it },
            )
            if (visibleParents.isNotEmpty()) {
                Text(
                    "父分类不能直接记账，请选择子分类（服务端会拒绝父分类）。",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (visibleCats.isEmpty()) {
                Text("暂无可用分类，请先添加后再保存。", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            }

            // 表单信息（账户、日期、标签、备注紧凑行）
            FinanceCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 14.dp,
                contentPadding = 12.dp,
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CategoryPicker(
                        label = "账户",
                        items = accounts.map { it.optString("id") to it.optString("name") },
                        selected = accountId,
                        onSelect = { accountId = it },
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { datePickerVisible = true }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("日期", style = MaterialTheme.typography.bodyMedium, color = LocalWebTokens.current.fg)
                        Text("$dateText ›", style = MaterialTheme.typography.bodyMedium, color = LocalWebTokens.current.muted)
                    }
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("备注") },
                        placeholder = { Text("请输入备注…") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = tagsText,
                        onValueChange = { tagsText = it },
                        label = { Text("标签") },
                        placeholder = { Text("可选，逗号分隔") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            // 内置数字键盘（对齐设计图：1-9, ., 0, 退格）
            AmountKeypad(
                onKey = { key ->
                    amountText = appendKeypadInput(amountText, key)
                    parsedPreview = parseYuanToCents(amountText)
                },
            )

            // 蓝色整宽保存按钮
            Button(
                enabled = !saving && formReady,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LocalWebTokens.current.accent),
                onClick = {
                    scope.launch {
                        val cents = parseYuanToCents(amountText)
                        if (cents == null || cents <= 0) {
                            error = "金额须为大于 0 的数字"
                            return@launch
                        }
                        if (categoryId.isEmpty() || accountId.isEmpty()) {
                            error = "请选择分类与账户"
                            return@launch
                        }
                        if (categoryId in visibleParents) {
                            error = "父分类不能直接记账，请选择子分类"
                            return@launch
                        }
                        saving = true
                        error = null
                        try {
                            val body = JSONObject()
                                .put("type", type)
                                .put("amountCents", cents)
                                .put("categoryId", categoryId)
                                .put("accountId", accountId)
                                .put("date", fromDateInput(dateText))
                                .put("note", note)
                                .put("isRefund", type == 1 && isRefund)
                                .put("tags", org.json.JSONArray(tagsText.split(',', '，').map { it.trim() }.filter { it.isNotEmpty() }))
                                .put("refundLinkedTxIds", org.json.JSONArray(if (type == 1 && isRefund) refundLinks.split(',', '，').map { it.trim() }.filter { it.isNotEmpty() } else emptyList<String>()))
                            if (editId == null) ledger.createTransaction(jsonToMap(body))
                            else ledger.updateTransaction(editId, jsonToMap(body))
                            onSaved()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: AuthExpiredException) {
                            onAuthExpired()
                        } catch (e: Exception) {
                            error = e.message ?: "保存失败"
                        } finally {
                            saving = false
                        }
                    }
                },
            ) {
                Text(if (saving) "保存中…" else "保存", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            if (type == 1) {
                FormSection(title = "退款关联", description = "退款仍是一笔收入，可关联原支出；原支出记录不会被改写。") {
                    FilterChip(
                        selected = isRefund,
                        onClick = { isRefund = !isRefund },
                        label = { Text(if (isRefund) "这是退款" else "标记为退款") },
                        modifier = Modifier.heightIn(min = 48.dp),
                    )
                    if (isRefund) {
                        LedgerLinkPicker(
                            api = api,
                            type = 0,
                            selected = refundLinks.split(',', '，').map { it.trim() }.filter { it.isNotBlank() }.toSet(),
                            onSelect = { refundLinks = it.joinToString(",") },
                            multiple = true,
                            onAuthExpired = onAuthExpired,
                        )
                    }
                }
            }

            if (error != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        error.orEmpty(),
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (datePickerVisible) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = datePickerUtcMillis(dateText))
        DatePickerDialog(
            onDismissRequest = { datePickerVisible = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { dateText = dateFromPickerUtcMillis(it) }
                    datePickerVisible = false
                }) { Text("确定") }
            },
            dismissButton = { TextButton(onClick = { datePickerVisible = false }) { Text("取消") } },
        ) {
            DatePicker(state = pickerState)
        }
    }

    if (discardConfirmation) {
        AlertDialog(
            onDismissRequest = { discardConfirmation = false },
            title = { Text("放弃未保存的账单？") },
            text = { Text("当前表单有未保存的修改，离开后这些内容将丢失。") },
            confirmButton = {
                TextButton(
                    onClick = {
                        discardConfirmation = false
                        onClose()
                    },
                ) { Text("放弃修改") }
            },
            dismissButton = {
                TextButton(onClick = { discardConfirmation = false }) { Text("继续编辑") }
            },
        )
    }
}

/** Numeric keypad appends to the same amount text; the system keyboard stays usable. */
@Composable
private fun AmountKeypad(onKey: (String) -> Unit) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf(".", "0", "back"),
    )
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { key ->
                    if (key == "back") {
                        Surface(
                            onClick = { onKey("back") },
                            modifier = Modifier.weight(1f).height(46.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = LocalWebTokens.current.surface,
                            border = BorderStroke(1.dp, LocalWebTokens.current.border.copy(alpha = 0.6f)),
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Filled.Backspace,
                                    contentDescription = "删除一位",
                                    modifier = Modifier.size(18.dp),
                                    tint = LocalWebTokens.current.fg,
                                )
                            }
                        }
                    } else {
                        Surface(
                            onClick = { onKey(key) },
                            modifier = Modifier.weight(1f).height(46.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = LocalWebTokens.current.surface,
                            border = BorderStroke(1.dp, LocalWebTokens.current.border.copy(alpha = 0.6f)),
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    key,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = LocalWebTokens.current.fg,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Keypad editing rule: digits append, single dot, empty-safe backspace.
 * Decimal input keeps at most two places; longer input is ignored, never reformatted.
 */
fun appendKeypadInput(current: String, key: String): String {
    if (key == "back") {
        if (current.isEmpty()) return ""
        return current.dropLast(1)
    }
    if (key == ".") {
        if (current.contains(".")) return current
        if (current.isEmpty()) return "0."
        return "$current."
    }
    if (key.length != 1 || !key[0].isDigit()) return current
    if (current.length >= 12) return current
    val dot = current.indexOf(".")
    if (dot >= 0 && current.length - dot - 1 >= 2) return current
    if (current == "0") return key
    return current + key
}

/** Parent categories have children pointing at them via parentId; the server rejects them. */
fun parentCategoryIds(cats: List<JSONObject>): Set<String> {
    val childParents = cats
        .mapNotNull { c -> c.optString("parentId").takeIf { !c.isNull("parentId") && it.isNotBlank() } }
        .toSet()
    if (childParents.isEmpty()) return emptySet()
    return cats.map { it.optString("id") }.filter { it.isNotBlank() && it in childParents }.toSet()
}

/** 4-column soft tiles with category icon and color; parent categories render disabled with a hint. */
@Composable
private fun CategoryGrid(
    items: List<JSONObject>,
    parentIds: Set<String>,
    selected: String,
    onSelect: (String) -> Unit,
) {
    if (items.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { item ->
                    val id = item.optString("id")
                    val name = item.optString("name").ifBlank { "未命名" }
                    val iconName = item.optString("icon", "other")
                    val colorVal = categoryThemeColor(iconName, item.optLong("color", 0L))
                    val isParent = id in parentIds
                    val isSelected = id == selected && !isParent

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .then(if (isParent) Modifier.alpha(0.45f) else Modifier)
                            .clickable(enabled = !isParent) { onSelect(id) },
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White,
                        border = BorderStroke(
                            if (isSelected) 1.5.dp else 1.dp,
                            if (isSelected) LocalWebTokens.current.accent
                            else LocalWebTokens.current.border,
                        ),
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            FinanceCategoryIcon(
                                iconName = iconName,
                                categoryName = name,
                                backgroundColor = Color(0xFFEAF0F1),
                                size = 36.dp,
                                iconSize = 18.dp,
                            )
                            Text(
                                name,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) LocalWebTokens.current.accent
                                else LocalWebTokens.current.muted,
                                maxLines = 1,
                            )
                            if (isParent) {
                                Text(
                                    "父分类",
                                    fontSize = 10.sp,
                                    color = LocalWebTokens.current.muted,
                                )
                            }
                        }
                    }
                }
                repeat(4 - row.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun FormSection(
    title: String,
    description: String,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            content()
        }
    }
}

@Composable
private fun CategoryPicker(
    label: String,
    items: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val current = items.firstOrNull { it.first == selected }?.second ?: if (selected.isNotEmpty()) "已选项目暂不可用" else "请选择$label"
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                Text(current, modifier = Modifier.weight(1f), maxLines = 1)
                Text("⌄")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                items.forEach { (id, name) ->
                    DropdownMenuItem(
                        text = { Text(if (id == selected) "✓  $name" else name) },
                        onClick = { onSelect(id); expanded = false },
                    )
                }
            }
        }
        if (items.isEmpty()) {
            Text("暂无可用$label，请先添加后再保存。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
}

/** Convert a yuan value exactly once at the API boundary. */
fun parseYuanToCents(text: String): Long? {
    val v = text.trim().toDoubleOrNull() ?: return null
    if (!v.isFinite() || v < 0 || v * 100 > 9_007_199_254_740_991.0) return null
    return Math.round(v * 100)
}

private fun todayInput(): String = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date())

private fun datePickerUtcMillis(text: String): Long {
    val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).apply {
        isLenient = false
        timeZone = TimeZone.getTimeZone("UTC")
    }
    return try {
        formatter.parse(text)?.time ?: formatter.parse(todayInput())!!.time
    } catch (_: Exception) {
        formatter.parse(todayInput())!!.time
    }
}

private fun dateFromPickerUtcMillis(epochMs: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).apply {
    timeZone = TimeZone.getTimeZone("UTC")
}.format(Date(epochMs))

private fun toDateInput(epochMs: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date(epochMs))

private fun fromDateInput(text: String): Long = parseDateInput(text)

private fun jsonToMap(o: JSONObject): Map<String, Any?> {
    val out = mutableMapOf<String, Any?>()
    val keys = o.keys()
    while (keys.hasNext()) {
        val k = keys.next()
        out[k] = o.opt(k)
    }
    return out
}
