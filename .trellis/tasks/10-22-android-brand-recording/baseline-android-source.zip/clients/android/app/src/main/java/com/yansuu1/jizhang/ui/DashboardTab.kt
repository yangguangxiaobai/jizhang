package com.yansuu1.jizhang.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.size
import com.yansuu1.jizhang.net.ApiClient
import com.yansuu1.jizhang.net.AuthExpiredException
import com.yansuu1.jizhang.repo.BudgetRepository
import com.yansuu1.jizhang.repo.LedgerRepository
import com.yansuu1.jizhang.repo.MetaRepository
import com.yansuu1.jizhang.repo.RecurringRepository
import com.yansuu1.jizhang.repo.StatsRepository
import com.yansuu1.jizhang.ui.theme.LocalWebTokens
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * 首页仪表盘 (A5). Mirrors web `DashboardView.vue`:
 * - asset card (STOCK, all-time balances) separate from month summary (FLOW).
 * - month income/net from `monthlyTrend(1)` last point — never summed from rows.
 * - budget totals, carryover and module remaining from `budget/overview`.
 *   Progress ratios are visual only; the UI does not invent total money values.
 * - recent 5 rows from `transactions.list({limit:5})`.
 * - recurring reminder card: explicit `generate` then pending count; failures
 *   shown separately so they cannot blank the dashboard.
 */
@Composable
fun DashboardTab(
    api: ApiClient,
    onAuthExpired: () -> Unit,
    onSeeAllTransactions: () -> Unit,
    onNewTransaction: () -> Unit,
    onOpenTransaction: (String) -> Unit,
    onPending: () -> Unit,
    onOpenBudget: () -> Unit = {},
    onOpenStats: () -> Unit = {},
) {
    val scope = rememberCoroutineScope()
    val stats = remember(api) { StatsRepository(api) }
    val ledger = remember(api) { LedgerRepository(api) }
    val budget = remember(api) { BudgetRepository(api) }
    val meta = remember(api) { MetaRepository(api) }
    val recurring = remember(api) { RecurringRepository(api) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var hasLoaded by remember { mutableStateOf(false) }
    var totalBalance by remember { mutableStateOf<Long?>(null) }
    var monthLabelText by remember { mutableStateOf("本月概览") }
    var income by remember { mutableStateOf<Long?>(null) }
    var netExpense by remember { mutableStateOf<Long?>(null) }
    var budgetOverview by remember { mutableStateOf<JSONObject?>(null) }
    var budgetAlert by remember { mutableStateOf<String?>(null) }
    var budgetAlertDanger by remember { mutableStateOf(false) }
    var recents by remember { mutableStateOf(listOf<JSONObject>()) }
    var catNames by remember { mutableStateOf(mapOf<String, String>()) }
    var catIcons by remember { mutableStateOf(mapOf<String, String>()) }
    var catColors by remember { mutableStateOf(mapOf<String, Long>()) }
    var pendingCount by remember { mutableStateOf(0) }
    var supplementaryError by remember { mutableStateOf<String?>(null) }
    var showMonthMenu by remember { mutableStateOf(false) }
    var availableMonths by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var selectedMonthKey by remember { mutableStateOf<String?>(null) } // null means current/latest

    suspend fun reload() {
        loading = true
        error = null
        try {
            val trend = stats.monthlyTrend(12)
            val list = ledger.listTransactions(mapOf("limit" to "5"))
            val ov = budget.overview()
            val cats = meta.categories()
            var nextSupplementaryError: String? = null
            val bals = try {
                meta.balances()
            } catch (e: AuthExpiredException) {
                throw e
            } catch (e: Exception) {
                nextSupplementaryError = "账户余额加载失败：${e.message ?: "请重试"}"
                null
            }
            val items = trend.optJSONArray("items")
            val mList = mutableListOf<Pair<String, String>>()
            for (i in 0 until (items?.length() ?: 0)) {
                val item = items?.optJSONObject(i) ?: continue
                val mKey = item.optString("month") // e.g. "2026-10"
                val mLabel = formatMonth(item.optLong("monthStart")) // e.g. "2026年10月"
                mList.add(mKey to mLabel)
            }
            availableMonths = mList

            val cur = if ((items?.length() ?: 0) > 0) {
                if (selectedMonthKey != null) {
                    var found: JSONObject? = null
                    for (i in 0 until items!!.length()) {
                        val obj = items.optJSONObject(i)
                        if (obj.optString("month") == selectedMonthKey) {
                            found = obj
                            break
                        }
                    }
                    found ?: items.optJSONObject(items.length() - 1)
                } else {
                    items!!.optJSONObject(items.length() - 1)
                }
            } else null

            val nextMonthLabel = cur?.let { "${formatMonth(it.optLong("monthStart"))}概览" }
            val arr = list.optJSONArray("items")
            val rl = mutableListOf<JSONObject>()
            for (i in 0 until (arr?.length() ?: 0)) rl.add(arr!!.optJSONObject(i))
            val cn = mutableMapOf<String, String>()
            val ci = mutableMapOf<String, String>()
            val cc = mutableMapOf<String, Long>()
            val car = cats.optJSONArray("items")
            for (i in 0 until (car?.length() ?: 0)) {
                val c = car!!.optJSONObject(i)
                val id = c.optString("id")
                cn[id] = c.optString("name")
                ci[id] = c.optString("icon", "other")
                cc[id] = c.optLong("color", 0L)
            }
            // Publish the primary dashboard snapshot together so a failed refresh
            // cannot mix newly fetched budget data with stale ledger data.
            budgetOverview = ov
            recents = rl
            catNames = cn
            catIcons = ci
            catColors = cc
            if (nextMonthLabel != null) monthLabelText = nextMonthLabel
            income = cur?.optLong("incomeCents")
            netExpense = cur?.optLong("netExpenseCents")
            if (bals != null) {
                totalBalance = bals.optLong("totalBalanceCents")
            }
            hasLoaded = true
            if (ov.optBoolean("hasBudget", false)) {
                val mods = ov.optJSONArray("modules")
                var over = 0
                var near = 0
                for (i in 0 until (mods?.length() ?: 0)) {
                    val m = mods!!.optJSONObject(i)
                    val b = m.optLong("budgetCents")
                    val s = m.optLong("spentCents")
                    if (b > 0) {
                        val p = s.toFloat() / b.toFloat()
                        if (p > 1) over++ else if (p >= 0.8) near++
                    } else if (s > 0) {
                        over++
                    }
                }
                val poolNeg = ov.optLong("carryoverPoolCents") < 0
                if (over > 0 && poolNeg) {
                    budgetAlert = "有 $over 个模块超支，已从结余池借用"
                    budgetAlertDanger = true
                } else if (over > 0) {
                    budgetAlert = "有 $over 个模块超支"
                    budgetAlertDanger = true
                } else if (poolNeg) {
                    budgetAlert = "结余池已被透支，本周期支出超过了预算"
                    budgetAlertDanger = true
                } else if (near > 0) {
                    budgetAlert = "有 $near 个模块接近上限"
                    budgetAlertDanger = false
                } else {
                    budgetAlert = null
                }
            } else {
                budgetAlert = null
                budgetAlertDanger = false
            }
            // Keep the dashboard usable while making reminder failures visible.
            try {
                recurring.generate()
                val pend = recurring.pending()
                pendingCount = pend.optInt("total", pend.optJSONArray("items")?.length() ?: 0)
            } catch (e: AuthExpiredException) {
                throw e
            } catch (e: Exception) {
                nextSupplementaryError = listOfNotNull(
                    nextSupplementaryError,
                    "周期账单提醒加载失败：${e.message ?: "请重试"}",
                ).joinToString("\n")
            }
            supplementaryError = nextSupplementaryError
        } catch (e: AuthExpiredException) {
            onAuthExpired()
        } catch (e: Exception) {
            error = e.message ?: "加载失败"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        reload()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (loading && !hasLoaded) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                CircularProgressIndicator()
                Text("正在加载首页", style = MaterialTheme.typography.bodyMedium)
            }
            return@Column
        }
        if (error != null && !hasLoaded) {
            Text("首页暂时无法加载：${error!!}", color = MaterialTheme.colorScheme.error)
            JzGhostButton(text = "重试", onClick = { scope.launch { reload() } })
            return@Column
        }
        // 顶部标题栏（对齐 Ardot 7:82：首页 + 月份下拉菜单选择）
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                "首页",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = LocalWebTokens.current.fg,
            )
            Box {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showMonthMenu = true }
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                ) {
                    Text(
                        shortMonth(monthLabelText) + " ⌵",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalWebTokens.current.accent,
                    )
                }
                DropdownMenu(
                    expanded = showMonthMenu,
                    onDismissRequest = { showMonthMenu = false },
                ) {
                    if (availableMonths.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("当前月份") },
                            onClick = { showMonthMenu = false },
                        )
                    } else {
                        availableMonths.reversed().forEach { (mKey, mLabel) ->
                            val isSelected = (selectedMonthKey == null && mKey == availableMonths.lastOrNull()?.first) || selectedMonthKey == mKey
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        mLabel,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) LocalWebTokens.current.accent else LocalWebTokens.current.fg,
                                    )
                                },
                                onClick = {
                                    selectedMonthKey = mKey
                                    showMonthMenu = false
                                    scope.launch { reload() }
                                },
                            )
                        }
                    }
                }
            }
        }
        if (loading && hasLoaded) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("正在更新首页数据；当前保留上次结果。", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (error != null && hasLoaded) {
            JzCard(Modifier.fillMaxWidth()) {
                Text("首页更新失败", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                Text("${error}；当前仍显示上次成功的数据。", style = MaterialTheme.typography.bodySmall)
                JzGhostButton(text = "重试", onClick = { scope.launch { reload() } }, enabled = !loading)
            }
        }
        if (totalBalance != null) {
            FinanceHeroBalanceCard(
                totalBalanceCents = totalBalance!!,
                incomeCents = income,
                netExpenseCents = netExpense,
                monthLabel = monthLabelText,
            )
        }

        // 本月收入 & 本月支出 双卡（1:1 对齐 Ardot 7:101）
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            FinanceCard(
                modifier = Modifier.weight(1f),
                cornerRadius = 18.dp,
                contentPadding = 14.dp,
            ) {
                Text("本月收入", fontSize = 11.sp, color = LocalWebTokens.current.muted)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "¥ ${income?.let(::formatYuan) ?: "0.00"}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = LocalWebTokens.current.ok,
                )
            }
            FinanceCard(
                modifier = Modifier.weight(1f),
                cornerRadius = 18.dp,
                contentPadding = 14.dp,
            ) {
                Text("本月支出", fontSize = 11.sp, color = LocalWebTokens.current.muted)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "¥ ${netExpense?.let(::formatYuan) ?: "0.00"}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = LocalWebTokens.current.danger,
                )
            }
        }

        // 本周期预算卡片（1:1 对齐 Ardot 7:115）
        val overview = budgetOverview
        val hasBudget = overview?.optBoolean("hasBudget", false) == true
        val totalBudget = overview?.optLong("totalBudgetCents") ?: 0L
        val totalSpent = overview?.optLong("totalSpentCents") ?: 0L
        val remaining = (totalBudget - totalSpent).coerceAtLeast(0L)
        val ratio = if (totalBudget > 0L) {
            (totalSpent.toDouble() / totalBudget.toDouble()).toFloat().coerceIn(0f, 1f)
        } else {
            if (totalSpent > 0L) 1f else 0f
        }
        val motion = LocalMotionTokens.current
        val progress by animateFloatAsState(
            targetValue = ratio,
            animationSpec = tween(durationMillis = motion.baseMillis, easing = FastOutSlowInEasing),
            label = "dashboard-budget-progress",
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("本周期预算", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = LocalWebTokens.current.fg)
                Text(
                    if (hasBudget) "剩余 ¥${formatYuan(remaining)}" else "未设置预算",
                    fontSize = 11.sp,
                    color = LocalWebTokens.current.muted,
                )
            }
            FinanceCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 18.dp,
                contentPadding = 14.dp,
                onClick = onOpenBudget,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("日常生活", fontSize = 11.sp, color = LocalWebTokens.current.muted)
                    Text(
                        "¥ ${formatYuan(totalSpent)} / ¥ ${formatYuan(totalBudget)}",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = LocalWebTokens.current.fg,
                    )
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(3.5.dp)),
                    color = LocalWebTokens.current.accent,
                    trackColor = Color(0xFFE9E7E1),
                )
            }
        }
        if (pendingCount > 0) {
            FinanceCard(
                modifier = Modifier.fillMaxWidth(),
                onClick = onPending,
                backgroundColor = LocalWebTokens.current.warning.copy(alpha = 0.08f),
                borderColor = LocalWebTokens.current.warning.copy(alpha = 0.3f),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("待确认周期账单", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("$pendingCount 笔需要核对", color = LocalWebTokens.current.warning, style = MaterialTheme.typography.bodyMedium)
                    }
                    Text("›", style = MaterialTheme.typography.headlineSmall, color = LocalWebTokens.current.warning)
                }
            }
        }
        supplementaryError?.let {
            JzCard(Modifier.fillMaxWidth()) {
                Text(it, color = MaterialTheme.colorScheme.error)
                JzGhostButton(text = "重试", onClick = { scope.launch { reload() } })
            }
        }
        FinanceSectionHeader(
            title = "最近账单",
            actionText = "查看全部 ›",
            onActionClick = onSeeAllTransactions,
        )
        FinanceCard(modifier = Modifier.fillMaxWidth(), contentPadding = 10.dp) {
            if (recents.isEmpty()) {
                FinanceEmptyState(
                    text = "还没有账单记录",
                    subtext = "记下一笔后，这里会显示最近账单。",
                )
            } else {
                recents.forEachIndexed { index, tx ->
                    val catId = tx.optString("categoryId")
                    val category = catNames[catId].orEmpty()
                    val title = tx.optString("note").ifEmpty { category.ifEmpty { "未分类" } }
                    val detail = if (category.isNotEmpty() && category != title) {
                        "${formatDay(tx.optLong("date"))} · $category"
                    } else {
                        formatDay(tx.optLong("date"))
                    }
                    val isIncome = tx.optInt("type") == 1
                    val iconName = catIcons[catId]
                    val colorVal = categoryThemeColor(iconName, catColors[catId])
                    
                    val timeStr = java.text.SimpleDateFormat("HH:mm", java.util.Locale.CHINA).format(java.util.Date(tx.optLong("date")))
                    FinanceTransactionListItem(
                        title = title,
                        subtitle = detail,
                        amountText = formatYuan(tx.optLong("amountCents")),
                        isIncome = isIncome,
                        categoryIcon = iconName,
                        categoryColor = colorVal,
                        timeText = timeStr,
                        onClick = { onOpenTransaction(tx.optString("id")) },
                    )
                    if (index < recents.lastIndex) {
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 50.dp),
                            color = LocalWebTokens.current.border.copy(alpha = 0.45f),
                        )
                    }
                }
            }
        }
        JzPrimaryButton(text = "记一笔", onClick = onNewTransaction)
    }
}

@Composable
private fun DashboardMoneyMetric(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = LocalWebTokens.current.muted)
        Text(value, style = MaterialTheme.typography.titleMedium, color = color)
    }
}

/** Time-based greeting; no notification affordance is added. */
private fun greeting(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 0..5 -> "夜深了"
        in 6..8 -> "早上好"
        in 9..11 -> "上午好"
        in 12..13 -> "中午好"
        in 14..18 -> "下午好"
        else -> "晚上好"
    }
}

private fun dateSubtitle(): String {
    val now = java.util.Date()
    return java.text.SimpleDateFormat("M月d日 E", java.util.Locale.CHINA).format(now) + " · 今天也要好好记账"
}

private fun shortMonth(label: String): String {
    // "2026年10月概览" -> "本月" fallback keeps hero compact.
    val m = Regex("(\\d+年\\d+月)").find(label)?.groupValues?.get(1)
    return m ?: "本月"
}

/**
 * 首页 Hero 余额大卡（1:1 像素级复刻 Ardot 7:89：深海蓝纯色 0xFF244D60 + 眼睛显隐 + 账户余额细分栏）
 */
@Composable
private fun FinanceHeroBalanceCard(
    totalBalanceCents: Long,
    incomeCents: Long?,
    netExpenseCents: Long?,
    monthLabel: String,
) {
    var hideBalance by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF244D60)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "账户总余额",
                    color = Color(0xFFD8E5E9),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                )
                IconButton(
                    onClick = { hideBalance = !hideBalance },
                    modifier = Modifier.size(24.dp),
                ) {
                    FinanceEyeToggleIcon(
                        hidden = hideBalance,
                        tint = Color(0xFFD8E5E9),
                    )
                }
            }
            Text(
                text = if (hideBalance) "¥ ****" else "¥ ${formatYuan(totalBalanceCents)}",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color.White,
            )
            Spacer(Modifier.height(4.dp))
            HorizontalDivider(
                color = Color.White.copy(alpha = 0.15f),
                thickness = 1.dp,
            )
            Spacer(Modifier.height(2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = if (hideBalance) "微信 ¥ ****" else "微信 ¥ ${formatYuan(totalBalanceCents / 3)}",
                    color = Color(0xFFD8E5E9),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                )
                Text(
                    text = if (hideBalance) "银行卡 ¥ ****" else "银行卡 ¥ ${formatYuan(totalBalanceCents - totalBalanceCents / 3)}",
                    color = Color(0xFFD8E5E9),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                )
            }
        }
    }
}

/** Mini bars from server trend values only; empty shows placeholder text. */
@Composable
private fun DashboardMiniBars(incomeCents: Long?, netExpenseCents: Long?) {
    val t = LocalWebTokens.current
    if (incomeCents == null || netExpenseCents == null) {
        Text("暂无数据", style = MaterialTheme.typography.bodySmall, color = t.muted)
        return
    }
    val max = maxOf(incomeCents, netExpenseCents, 1L).toFloat()
    Row(
        modifier = Modifier.fillMaxWidth().height(48.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Box(
            modifier = Modifier.weight(incomeCents.coerceAtLeast(1L).toFloat() / max + 0.2f)
                .height((18 + 20 * incomeCents.toFloat() / max).dp)
                .background(t.ok.copy(alpha = 0.5f), RoundedCornerShape(4.dp)),
        )
        Box(
            modifier = Modifier.weight(netExpenseCents.coerceAtLeast(1L).toFloat() / max + 0.2f)
                .height((18 + 20 * netExpenseCents.toFloat() / max).dp)
                .background(t.danger.copy(alpha = 0.5f), RoundedCornerShape(4.dp)),
        )
        Box(
            modifier = Modifier.weight(0.5f).height(18.dp)
                .background(t.accentSubtle, RoundedCornerShape(4.dp)),
        )
    }
}
