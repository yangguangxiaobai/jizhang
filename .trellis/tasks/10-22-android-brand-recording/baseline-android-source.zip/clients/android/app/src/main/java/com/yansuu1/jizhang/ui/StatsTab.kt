package com.yansuu1.jizhang.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.yansuu1.jizhang.net.ApiClient
import com.yansuu1.jizhang.net.AuthExpiredException
import com.yansuu1.jizhang.repo.StatsRepository
import java.util.Calendar
import java.util.Locale
import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject

private data class StatsWindowOption(val key: String, val label: String)

private val statsWindowOptions = listOf(
    StatsWindowOption("thisMonth", "本月"),
    StatsWindowOption("last30", "近 30 天"),
    StatsWindowOption("last3Months", "近 3 个月"),
    StatsWindowOption("month", "指定月"),
)

@Composable
fun StatsTab(
    api: ApiClient,
    onAuthExpired: () -> Unit,
    onBack: () -> Unit = {},
) {
    val repo = remember(api) { StatsRepository(api) }
    var windowKind by remember { mutableStateOf("thisMonth") }
    var selectedMonth by remember { mutableStateOf(currentMonthString()) }
    var pickerYear by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    var pickerMonth by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.MONTH) + 1) }
    var monthPickerOpen by remember { mutableStateOf(false) }
    var months by remember { mutableIntStateOf(6) }
    var showCharts by remember { mutableStateOf(true) }

    var shareItems by remember(api) { mutableStateOf(listOf<JSONObject>()) }
    var shareTotal by remember(api) { mutableStateOf(0L) }
    var categoryDataLoaded by remember(api) { mutableStateOf(false) }
    var categoryLoadedLabel by remember(api) { mutableStateOf<String?>(null) }
    var categoryLoading by remember(api) { mutableStateOf(true) }
    var categoryError by remember(api) { mutableStateOf<String?>(null) }
    var categoryRetry by remember(api) { mutableIntStateOf(0) }
    var categoryRequest by remember(api) { mutableIntStateOf(0) }
    var range by remember(api) { mutableStateOf<JSONObject?>(null) }

    var trendPoints by remember(api) { mutableStateOf(listOf<JSONObject>()) }
    var trendDataLoaded by remember(api) { mutableStateOf(false) }
    var trendLoadedMonths by remember(api) { mutableIntStateOf(6) }
    var trendLoading by remember(api) { mutableStateOf(true) }
    var trendError by remember(api) { mutableStateOf<String?>(null) }
    var trendRetry by remember(api) { mutableIntStateOf(0) }
    var trendRequest by remember(api) { mutableIntStateOf(0) }

    var poolPoints by remember(api) { mutableStateOf(listOf<JSONObject>()) }
    var poolDataLoaded by remember(api) { mutableStateOf(false) }
    var poolLoading by remember(api) { mutableStateOf(true) }
    var poolError by remember(api) { mutableStateOf<String?>(null) }
    var poolRetry by remember(api) { mutableIntStateOf(0) }
    var poolRequest by remember(api) { mutableIntStateOf(0) }

    var authExpiredHandled by remember(api) { mutableStateOf(false) }
    fun handleAuthExpired() {
        if (!authExpiredHandled) {
            authExpiredHandled = true
            onAuthExpired()
        }
    }

    // Category-share range is independent from the trend's 3/6/12-month window.
    LaunchedEffect(repo, windowKind, selectedMonth, categoryRetry) {
        val requestId = categoryRequest + 1
        categoryRequest = requestId
        val requestedWindow = windowKind
        val requestedMonth = selectedMonth
        categoryLoading = true
        categoryError = null
        try {
            val rangeResponse = repo.range()
            val (from, to) = if (requestedWindow == "month") {
                val bounds = repo.monthWindow(parseDateInput("$requestedMonth-01"))
                bounds.getLong("from") to bounds.getLong("to")
            } else {
                statsWindow(requestedWindow)
            }
            val share = repo.categoryShare(from, to)
            if (requestId == categoryRequest) {
                range = rangeResponse
                shareItems = share.optJSONArray("items").toJsonObjects()
                shareTotal = share.getLong("totalCents")
                categoryLoadedLabel = statsWindowLabel(requestedWindow, requestedMonth)
                categoryDataLoaded = true
            }
        } catch (e: AuthExpiredException) {
            handleAuthExpired()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (requestId == categoryRequest) categoryError = e.message ?: "分类统计加载失败。"
        } finally {
            if (requestId == categoryRequest) categoryLoading = false
        }
    }

    // The series request remains the source of every plotted value. Changing its
    // month count does not change the category-share range.
    LaunchedEffect(repo, months, trendRetry) {
        val requestId = trendRequest + 1
        trendRequest = requestId
        val requestedMonths = months
        trendLoading = true
        trendError = null
        try {
            val response = repo.monthlyTrend(requestedMonths)
            if (requestId == trendRequest) {
                trendPoints = response.optJSONArray("items").toJsonObjects()
                trendLoadedMonths = requestedMonths
                trendDataLoaded = true
            }
        } catch (e: AuthExpiredException) {
            handleAuthExpired()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (requestId == trendRequest) trendError = e.message ?: "月度趋势加载失败。"
        } finally {
            if (requestId == trendRequest) trendLoading = false
        }
    }

    LaunchedEffect(repo, poolRetry) {
        val requestId = poolRequest + 1
        poolRequest = requestId
        poolLoading = true
        poolError = null
        try {
            val response = repo.poolTrend()
            if (requestId == poolRequest) {
                poolPoints = response.optJSONArray("points").toJsonObjects()
                poolDataLoaded = true
            }
        } catch (e: AuthExpiredException) {
            handleAuthExpired()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (requestId == poolRequest) poolError = e.message ?: "结余池趋势加载失败。"
        } finally {
            if (requestId == poolRequest) poolLoading = false
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("统计", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "分类区间与收支趋势分别筛选；图表沿用服务端返回的数据。",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        JzCard {
            Text("显示方式", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = showCharts,
                    onClick = { showCharts = true },
                    label = { Text("图表") },
                )
                FilterChip(
                    selected = !showCharts,
                    onClick = { showCharts = false },
                    label = { Text("明细") },
                )
            }
        }

        JzCard {
            Text("分类统计区间", style = MaterialTheme.typography.titleMedium)
            Text(
                "与下方收支趋势的月数互相独立。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                statsWindowOptions.take(2).forEach { option ->
                    FilterChip(
                        modifier = Modifier.weight(1f),
                        selected = windowKind == option.key,
                        onClick = { windowKind = option.key },
                        label = { Text(option.label) },
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                statsWindowOptions.drop(2).forEach { option ->
                    FilterChip(
                        modifier = Modifier.weight(1f),
                        selected = windowKind == option.key,
                        onClick = { windowKind = option.key },
                        label = { Text(option.label) },
                    )
                }
            }
            if (windowKind == "month") {
                OutlinedButton(
                    onClick = {
                        parseYearMonth(selectedMonth)?.let { (year, month) ->
                            pickerYear = year
                            pickerMonth = month
                        }
                        monthPickerOpen = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("选择月份 · ${formatMonthLabel(selectedMonth)}")
                }
            }
            range?.let { response ->
                if (!response.isNull("earliest")) {
                    Text(
                        "账本最早记录：${formatDay(response.optLong("earliest"))}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        JzCard {
            Text("分类占比", style = MaterialTheme.typography.titleLarge)
            categoryLoadedLabel?.let {
                Text("显示范围：$it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (categoryLoading) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    if (categoryDataLoaded) "正在更新，保留上次成功的数据。" else "正在读取分类统计…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            categoryError?.let { message ->
                StatsError(message, categoryLoadedLabel, onRetry = { categoryRetry += 1 })
            }
            if (categoryDataLoaded) {
                DonutChart(slices = shareItems, totalCents = shareTotal, showChart = showCharts)
            }
        }

        JzCard {
            Text("收支月趋势", style = MaterialTheme.typography.titleLarge)
            Text(
                "月数仅控制本图；分类统计和结余池区间不随它变化。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(3, 6, 12).forEach { count ->
                    FilterChip(
                        selected = months == count,
                        onClick = { months = count },
                        label = { Text("$count 个月") },
                    )
                }
            }
            if (trendLoading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    if (trendDataLoaded) "正在更新，保留上次成功的数据。" else "正在读取月度趋势…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            trendError?.let { message ->
                StatsError(message, "最近 $trendLoadedMonths 个月", onRetry = { trendRetry += 1 })
            }
            if (trendDataLoaded) {
                Text(
                    "显示最近 $trendLoadedMonths 个月的服务端数据。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                MonthlyBars(points = trendPoints, showChart = showCharts)
            }
        }

        JzCard {
            Text("结余池趋势", style = MaterialTheme.typography.titleLarge)
            if (poolLoading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    if (poolDataLoaded) "正在更新，保留上次成功的数据。" else "正在读取结余池趋势…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            poolError?.let { message ->
                StatsError(message, null, onRetry = { poolRetry += 1 })
            }
            if (poolDataLoaded) {
                PoolSparkline(points = poolPoints, showChart = showCharts)
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (monthPickerOpen) {
        AlertDialog(
            onDismissRequest = { monthPickerOpen = false },
            title = { Text("选择统计月份") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        OutlinedButton(onClick = { pickerYear = (pickerYear - 1).coerceAtLeast(1) }) { Text("上一年") }
                        Text("${pickerYear}年", style = MaterialTheme.typography.titleMedium)
                        OutlinedButton(onClick = { pickerYear = (pickerYear + 1).coerceAtMost(9999) }) { Text("下一年") }
                    }
                    (1..12).toList().chunked(3).forEach { rowMonths ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            rowMonths.forEach { month ->
                                FilterChip(
                                    modifier = Modifier.weight(1f),
                                    selected = pickerMonth == month,
                                    onClick = { pickerMonth = month },
                                    label = { Text("${month}月") },
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        selectedMonth = "%04d-%02d".format(Locale.ROOT, pickerYear, pickerMonth)
                        monthPickerOpen = false
                    },
                ) { Text("应用月份") }
            },
            dismissButton = {
                TextButton(onClick = { monthPickerOpen = false }) { Text("取消") }
            },
        )
    }
}

@Composable
private fun StatsError(message: String, previousDataLabel: String?, onRetry: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("统计更新失败", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
        Text(message, style = MaterialTheme.typography.bodySmall)
        if (previousDataLabel != null) {
            Text(
                "仍显示上次成功的 $previousDataLabel 数据。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        OutlinedButton(onClick = onRetry) { Text("重试") }
    }
}

private fun JSONArray?.toJsonObjects(): List<JSONObject> = buildList {
    for (index in 0 until (this@toJsonObjects?.length() ?: 0)) {
        this@toJsonObjects?.optJSONObject(index)?.let(::add)
    }
}

private fun currentMonthString(): String {
    val calendar = Calendar.getInstance()
    return "%04d-%02d".format(Locale.ROOT, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1)
}

private fun parseYearMonth(value: String): Pair<Int, Int>? {
    val parts = value.split('-')
    if (parts.size != 2) return null
    val year = parts[0].toIntOrNull() ?: return null
    val month = parts[1].toIntOrNull() ?: return null
    if (year !in 1..9999 || month !in 1..12) return null
    return year to month
}

private fun formatMonthLabel(value: String): String {
    val (year, month) = parseYearMonth(value) ?: return value
    return "${year}年${month}月"
}

private fun statsWindowLabel(kind: String, month: String): String = when (kind) {
    "last30" -> "近 30 天"
    "last3Months" -> "近 3 个月"
    "month" -> formatMonthLabel(month)
    else -> "本月"
}

/** Web `windowFor` parity: [from, to) in local time. */
private fun statsWindow(kind: String): Pair<Long, Long> {
    val now = Calendar.getInstance()
    val endMonth = Calendar.getInstance()
    endMonth.set(Calendar.DAY_OF_MONTH, 1)
    endMonth.set(Calendar.HOUR_OF_DAY, 0)
    endMonth.set(Calendar.MINUTE, 0)
    endMonth.set(Calendar.SECOND, 0)
    endMonth.set(Calendar.MILLISECOND, 0)
    endMonth.add(Calendar.MONTH, 1)
    val to = endMonth.timeInMillis
    return when (kind) {
        "last30" -> now.timeInMillis - 30L * 86_400_000L to to
        "last3Months" -> {
            val from = Calendar.getInstance()
            from.set(Calendar.DAY_OF_MONTH, 1)
            from.set(Calendar.HOUR_OF_DAY, 0)
            from.set(Calendar.MINUTE, 0)
            from.set(Calendar.SECOND, 0)
            from.set(Calendar.MILLISECOND, 0)
            from.add(Calendar.MONTH, -2)
            from.timeInMillis to to
        }
        else -> {
            val from = Calendar.getInstance()
            from.set(Calendar.DAY_OF_MONTH, 1)
            from.set(Calendar.HOUR_OF_DAY, 0)
            from.set(Calendar.MINUTE, 0)
            from.set(Calendar.SECOND, 0)
            from.set(Calendar.MILLISECOND, 0)
            from.timeInMillis to to
        }
    }
}
