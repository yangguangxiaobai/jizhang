package com.yansuu1.jizhang.ui

object ProviderSettingsHelper {

    val POPULAR_MODELS = listOf(
        "gpt-4o-mini",
        "gpt-4o",
        "deepseek-chat",
        "deepseek-reasoner",
        "claude-3-5-sonnet",
        "qwen-plus"
    )

    /**
     * 智能规范化用户输入的 URL。
     * 当用户在 New API / OpenAI 兼容模式下输入根域名或 /v1 时，自动补全为标准的 /v1/chat/completions。
     */
    fun normalizeUrl(input: String, mode: String = "chat-completions"): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return ""
        if (mode != "chat-completions") return trimmed

        val clean = trimmed.trimEnd('/')
        return when {
            clean.endsWith("/v1/chat/completions", ignoreCase = true) -> clean
            clean.endsWith("/chat/completions", ignoreCase = true) -> clean
            clean.endsWith("/v1", ignoreCase = true) -> "$clean/chat/completions"
            clean.startsWith("http://", ignoreCase = true) || clean.startsWith("https://", ignoreCase = true) -> {
                "$clean/v1/chat/completions"
            }
            else -> clean
        }
    }

    /**
     * 判断当前 URL 是否匹配 New API / OpenAI 兼容中转站的常见模式
     */
    fun isOpenAiCompatible(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("/chat/completions")
    }
}
