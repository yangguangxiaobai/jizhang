package com.yansuu1.jizhang.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProviderSettingsHelperTest {

    @Test
    fun normalizeUrl_rootDomain_appendsV1ChatCompletions() {
        assertEquals(
            "https://api.openai.com/v1/chat/completions",
            ProviderSettingsHelper.normalizeUrl("https://api.openai.com")
        )
        assertEquals(
            "https://my-new-api.com/v1/chat/completions",
            ProviderSettingsHelper.normalizeUrl("https://my-new-api.com/")
        )
    }

    @Test
    fun normalizeUrl_v1Path_appendsChatCompletions() {
        assertEquals(
            "https://api.deepseek.com/v1/chat/completions",
            ProviderSettingsHelper.normalizeUrl("https://api.deepseek.com/v1")
        )
        assertEquals(
            "https://api.deepseek.com/v1/chat/completions",
            ProviderSettingsHelper.normalizeUrl("https://api.deepseek.com/v1/")
        )
    }

    @Test
    fun normalizeUrl_fullPath_preserves() {
        assertEquals(
            "https://api.openai.com/v1/chat/completions",
            ProviderSettingsHelper.normalizeUrl("https://api.openai.com/v1/chat/completions")
        )
    }

    @Test
    fun normalizeUrl_customMode_preservesExact() {
        assertEquals(
            "https://custom-api.com/custom/endpoint",
            ProviderSettingsHelper.normalizeUrl("https://custom-api.com/custom/endpoint", mode = "custom")
        )
    }

    @Test
    fun isOpenAiCompatible_detectsCorrectly() {
        assertTrue(ProviderSettingsHelper.isOpenAiCompatible("https://api.new-api.com/v1/chat/completions"))
        assertFalse(ProviderSettingsHelper.isOpenAiCompatible("https://api.anthropic.com/v1/messages"))
    }
}
