package com.yansuu1.jizhang.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.yansuu1.jizhang.net.ApiClient
import com.yansuu1.jizhang.net.AuthExpiredException
import com.yansuu1.jizhang.repo.AdminRepository
import com.yansuu1.jizhang.repo.LedgerRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Read-only bill detail keeps the summary and refund relationship out of the editor. */
@Composable
fun TransactionDetailScreen(
    api: ApiClient,
    transactionId: String,
    onAuthExpired: () -> Unit,
    onBack: () -> Unit,
    onEdit: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val ledger = remember(api) { LedgerRepository(api) }
    val admin = remember(api) { AdminRepository(api) }
    var transaction by remember(transactionId) { mutableStateOf<JSONObject?>(null) }
    var linkedTransactions by remember(transactionId) { mutableStateOf(emptyList<JSONObject>()) }
    var categoryNames by remember(transactionId) { mutableStateOf(emptyMap<String, String>()) }
    var accountNames by remember(transactionId) { mutableStateOf(emptyMap<String, String>()) }
    var loading by remember(transactionId) { mutableStateOf(true) }
    var error by remember(transactionId) { mutableStateOf<String?>(null) }

    suspend fun reload() {
        loading = true
        error = null
        try {
            val item = ledger.getTransaction(transactionId)
            transaction = item
            try {
                val categories = admin.categories(includeDeleted = true).optJSONArray("items")
                categoryNames = (0 until (categories?.length() ?: 0)).mapNotNull { index ->
                    categories?.optJSONObject(index)?.let {
                        it.optString("id") to it.optString("name")
                    }
                }.toMap()
                val accounts = admin.accounts(includeDeleted = true).optJSONArray("items")
                accountNames = (0 until (accounts?.length() ?: 0)).mapNotNull { index ->
                    accounts?.optJSONObject(index)?.let {
                        it.optString("id") to it.optString("name")
                    }
                }.toMap()
            } catch (e: AuthExpiredException) {
                throw e
            } catch (_: Exception) {
                categoryNames = emptyMap()
                accountNames = emptyMap()
            }
            val links = item.optJSONArray("refundLinkedTxIds")
            linkedTransactions = buildList {
                for (index in 0 until (links?.length() ?: 0)) {
                    val linkedId = links?.optString(index).orEmpty()
                    if (linkedId.isBlank()) continue
                    runCatching { ledger.getTransaction(linkedId) }.getOrNull()?.let(::add)
                }
            }
        } catch (e: AuthExpiredException) {
            onAuthExpired()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message?.takeIf(String::isNotBlank) ?: "账单详情暂时无法加载。"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(transactionId) { reload() }
    BackHandler { onBack() }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            JzGhostButton(text = "返回账单", onClick = onBack)
            Text("账单详情", style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = onEdit, enabled = transaction != null) {
                Icon(Icons.Filled.Edit, contentDescription = "编辑账单")
            }
        }
        if (loading && transaction == null) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                CircularProgressIndicator()
                Text("正在读取账单详情…")
            }
        }
        if (error != null) {
            Text(error!!, color = MaterialTheme.colorScheme.error)
            JzGhostButton(text = "重试", onClick = { scope.launch { reload() } })
        }
        val item = transaction
        if (item != null) {
            val isIncome = item.optInt("type") == 1
            val amountColor = if (isIncome) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            val prefix = if (isIncome) "+" else "−"
            JzCard(Modifier.fillMaxWidth()) {
                Text(
                    when {
                        item.optBoolean("isRefund") -> "退款收入"
                        isIncome -> "收入"
                        else -> "支出"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = amountColor,
                )
                Text(
                    prefix + formatYuan(item.optLong("amountCents")),
                    style = MaterialTheme.typography.headlineLarge,
                    color = amountColor,
                )
            }
            JzCard(Modifier.fillMaxWidth()) {
                Text("账单信息", style = MaterialTheme.typography.titleSmall)
                DetailValue(
                    "分类",
                    categoryNames[item.optString("categoryId")]
                        ?: item.optString("categoryName").ifBlank { "分类已删除" },
                )
                DetailValue(
                    "账户",
                    accountNames[item.optString("accountId")]
                        ?: item.optString("accountName").ifBlank { "账户已删除" },
                )
                DetailValue("日期", formatDay(item.optLong("date")))
                if (item.optString("note").isNotBlank()) DetailValue("备注", item.optString("note"))
                val tags = item.optJSONArray("tags")
                if (tags != null && tags.length() > 0) {
                    DetailValue(
                        "标签",
                        (0 until tags.length()).map { tags.optString(it) }.filter { it.isNotBlank() }
                            .joinToString(" · ") { "#$it" },
                    )
                }
            }
            if (item.optBoolean("isRefund")) {
                JzCard(Modifier.fillMaxWidth()) {
                    Text("关联原支出", style = MaterialTheme.typography.titleSmall)
                    if (linkedTransactions.isEmpty()) {
                        Text(
                            "未读取到关联账单详情；关联关系仍保留在这笔退款中。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        linkedTransactions.forEach { linked ->
                            val title = linked.optString("note").ifBlank {
                                categoryNames[linked.optString("categoryId")].orEmpty().ifBlank { "支出账单" }
                            }
                            DetailValue(
                                title,
                                formatDay(linked.optLong("date")) + " · " +
                                    formatYuan(linked.optLong("amountCents")),
                            )
                        }
                    }
                }
            }
            if (loading) {
                Text("正在更新详情…", style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun DetailValue(label: String, value: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
