package com.yansuu1.jizhang.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontFamily
import com.yansuu1.jizhang.ui.theme.LocalWebTokens
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.yansuu1.jizhang.net.ApiClient
import com.yansuu1.jizhang.net.AuthExpiredException
import com.yansuu1.jizhang.repo.AdminRepository
import com.yansuu1.jizhang.repo.LedgerRepository
import com.yansuu1.jizhang.repo.MetaRepository
import java.util.Calendar
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Monthly transaction list. Query parameters and their meanings remain aligned
 * with LedgerRepository; money and budget values are displayed as returned.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionsTab(
    api: ApiClient,
    onAuthExpired: () -> Unit,
    onNew: () -> Unit,
    onOpen: (String) -> Unit,
    onEdit: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val ledger = remember(api) { LedgerRepository(api) }
    val meta = remember(api) { MetaRepository(api) }
    val admin = remember(api) { AdminRepository(api) }

    val loadCoordinator = remember { TransactionLoadCoordinator() }
    val metadataCoordinator = remember { TransactionMetadataCoordinator() }
    var viewState by remember { mutableStateOf(loadCoordinator.state) }
    var metadataState by remember { mutableStateOf(metadataCoordinator.state) }
    var loadJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var metadataJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    var confirmDelete by remember { mutableStateOf<JSONObject?>(null) }
    var searchText by remember { mutableStateOf("") }
    var showFilters by remember { mutableStateOf(false) }
    var draftAccountFilter by remember { mutableStateOf<String?>(null) }
    var draftCategoryFilter by remember { mutableStateOf("") }
    var draftTagFilter by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf(false) }
    var deleteError by remember { mutableStateOf<String?>(null) }
    var searchFocus by remember { mutableStateOf(false) }

    val activeFilterCount = listOfNotNull(
        viewState.currentQuery.accountId,
        viewState.currentQuery.categoryId.takeIf { it.isNotEmpty() },
        viewState.currentQuery.tag.takeIf { it.isNotEmpty() },
    ).size

    suspend fun executeLoad(initialQuery: TransactionQuery, initialGen: Long) {
        var currentTarget = initialQuery
        var currentGen = initialGen
        while (true) {
            val stepGen = currentGen
            val stepQuery = currentTarget
            coroutineContext.ensureActive()
            try {
                val (from, to) = monthRange(stepQuery.monthOffset)
                val params = stepQuery.toServerParams(from, to)
                val res = ledger.listTransactions(params)
                coroutineContext.ensureActive()
                val arr = res.optJSONArray("items")
                val list = mutableListOf<JSONObject>()
                for (i in 0 until (arr?.length() ?: 0)) {
                    arr?.optJSONObject(i)?.let { list.add(it) }
                }
                val totalCount = res.optInt("total", list.size)
                when (val outcome = loadCoordinator.onLoadSuccess(stepGen, stepQuery, list, totalCount)) {
                    is TransactionLoadCoordinator.LoadResultOutcome.PageCorrectionRequired -> {
                        currentTarget = stepQuery.copy(page = outcome.correctedPage)
                        currentGen = loadCoordinator.startLoad(currentTarget)
                        viewState = loadCoordinator.state
                        continue
                    }
                    is TransactionLoadCoordinator.LoadResultOutcome.Applied -> {
                        viewState = loadCoordinator.state
                        return
                    }
                    TransactionLoadCoordinator.LoadResultOutcome.RejectedStale -> {
                        return
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: AuthExpiredException) {
                if (stepGen == loadCoordinator.currentGeneration()) {
                    onAuthExpired()
                }
                return
            } catch (e: Exception) {
                val errorMsg = e.message ?: "加载失败"
                if (loadCoordinator.onLoadError(stepGen, stepQuery, errorMsg)) {
                    viewState = loadCoordinator.state
                }
                return
            } finally {
                if (loadCoordinator.onLoadFinally(stepGen, stepQuery)) {
                    viewState = loadCoordinator.state
                }
            }
        }
    }

    fun dispatchQuery(newQuery: TransactionQuery) {
        val gen = loadCoordinator.startLoad(newQuery)
        viewState = loadCoordinator.state
        loadJob?.cancel()
        loadJob = scope.launch {
            executeLoad(newQuery, gen)
        }
    }

    fun dispatchMetadata() {
        val accGen = metadataCoordinator.startAccountsLoad()
        val otherGen = metadataCoordinator.startOtherMetadataLoad()
        metadataState = metadataCoordinator.state
        metadataJob?.cancel()
        metadataJob = scope.launch {
            launch {
                coroutineContext.ensureActive()
                try {
                    val accs = admin.accounts(includeDeleted = true).optJSONArray("items")
                    coroutineContext.ensureActive()
                    val an = mutableMapOf<String, String>()
                    for (i in 0 until (accs?.length() ?: 0)) {
                        val a = accs?.optJSONObject(i) ?: continue
                        an[a.optString("id")] = a.optString("name")
                    }
                    if (metadataCoordinator.onAccountsSuccess(accGen, an)) {
                        metadataState = metadataCoordinator.state
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: AuthExpiredException) {
                    if (accGen == metadataCoordinator.currentAccountsGeneration()) {
                        onAuthExpired()
                    }
                } catch (e: Exception) {
                    val errorMsg = e.message ?: "账户加载失败"
                    if (metadataCoordinator.onAccountsError(accGen, errorMsg)) {
                        metadataState = metadataCoordinator.state
                    }
                }
            }
            launch {
                coroutineContext.ensureActive()
                try {
                    val cats = admin.categories(includeDeleted = true).optJSONArray("items")
                    val tagRows = meta.tags().optJSONArray("items")
                    coroutineContext.ensureActive()
                    val cn = mutableMapOf<String, String>()
                    val ci = mutableMapOf<String, String>()
                    val cc = mutableMapOf<String, Long>()
                    for (i in 0 until (cats?.length() ?: 0)) {
                        val c = cats?.optJSONObject(i) ?: continue
                        val id = c.optString("id")
                        cn[id] = c.optString("name")
                        ci[id] = c.optString("icon", "other")
                        cc[id] = c.optLong("color", 0L)
                    }
                    val tg = (0 until (tagRows?.length() ?: 0))
                        .mapNotNull { tagRows?.optJSONObject(it)?.optString("name") }

                    if (metadataCoordinator.onOtherMetadataSuccess(otherGen, cn, ci, cc, tg)) {
                        metadataState = metadataCoordinator.state
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: AuthExpiredException) {
                    if (otherGen == metadataCoordinator.currentOtherGeneration()) {
                        onAuthExpired()
                    }
                } catch (e: Exception) {
                    val errorMsg = e.message ?: "分类标签加载失败"
                    if (metadataCoordinator.onOtherMetadataError(otherGen, errorMsg)) {
                        metadataState = metadataCoordinator.state
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        dispatchMetadata()
        dispatchQuery(viewState.currentQuery)
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        // 顶部标题栏（1:1 对齐 Ardot 7:176：账单 + 右上角「+ 记一笔」按钮）
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                "账单",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = LocalWebTokens.current.fg,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onNew() }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
            ) {
                Text(
                    "+ 记一笔",
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = LocalWebTokens.current.accent,
                )
            }
        }

        if (searchFocus) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    modifier = Modifier.weight(1f),
                    label = { Text("搜索备注") },
                    singleLine = true,
                )
                Button(onClick = {
                    val q = searchText.trim()
                    searchFocus = false
                    dispatchQuery(viewState.currentQuery.copy(search = q, page = 0))
                }, enabled = !viewState.loading) {
                    Text("搜索")
                }
                TextButton(onClick = { searchFocus = false; searchText = viewState.currentQuery.search }) { Text("收起") }
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(8.dp))
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                IconButton(
                    onClick = { dispatchQuery(TransactionQueryHelper.changeMonth(viewState.currentQuery, -1)) },
                    modifier = Modifier.size(44.dp),
                ) {
                    Text("‹", style = MaterialTheme.typography.headlineMedium)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(monthLabel(viewState.currentQuery.monthOffset), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    val countLabel = if (viewState.total != null) "${viewState.total} 笔" else if (viewState.loading) "…" else "条数暂不可用"
                    Text(countLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(
                    onClick = { dispatchQuery(TransactionQueryHelper.changeMonth(viewState.currentQuery, 1)) },
                    modifier = Modifier.size(44.dp),
                ) {
                    Text("›", style = MaterialTheme.typography.headlineMedium)
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        val accountChoices = remember(metadataState.accountNames, viewState.currentQuery.accountId) {
            TransactionQueryHelper.buildAccountChoices(
                accountNames = metadataState.accountNames,
                selectedAccountId = viewState.currentQuery.accountId,
            )
        }
        ListChoice(
            label = "账户",
            choices = accountChoices,
            selected = viewState.currentQuery.accountId ?: "",
            onSelect = { selectedId ->
                val newQuery = TransactionQueryHelper.selectAccount(viewState.currentQuery, selectedId)
                if (newQuery != null) {
                    dispatchQuery(newQuery)
                }
            },
        )
        if (metadataState.accountsLoading) {
            Text(
                "正在加载账户…",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        if (metadataState.accountsError != null) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "账户列表加载失败：${metadataState.accountsError}",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { dispatchMetadata() }) {
                    Text("重试")
                }
            }
        }
        if (metadataState.metadataError != null) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "分类标签加载失败：${metadataState.metadataError}",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { dispatchMetadata() }) {
                    Text("重试")
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = viewState.currentQuery.typeFilter == null,
                    onClick = { TransactionQueryHelper.selectType(viewState.currentQuery, null)?.let(::dispatchQuery) },
                    label = { Text("全部") },
                )
                FilterChip(
                    selected = viewState.currentQuery.typeFilter == 0,
                    onClick = { TransactionQueryHelper.selectType(viewState.currentQuery, 0)?.let(::dispatchQuery) },
                    label = { Text("支出") },
                )
                FilterChip(
                    selected = viewState.currentQuery.typeFilter == 1,
                    onClick = { TransactionQueryHelper.selectType(viewState.currentQuery, 1)?.let(::dispatchQuery) },
                    label = { Text("收入") },
                )
            }
            if (activeFilterCount > 0) {
                Spacer(Modifier.size(6.dp))
                Text("已选$activeFilterCount", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
        }

        if (viewState.currentQuery.accountId != null) {
            Text(
                "账户：${TransactionQueryHelper.accountDisplayLabel(viewState.currentQuery.accountId, metadataState.accountNames)} · 仅显示${monthLabel(viewState.currentQuery.monthOffset)}的账单",
                modifier = Modifier.padding(top = 2.dp, bottom = 2.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (activeFilterCount > 0 || viewState.currentQuery.search.isNotBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                viewState.currentQuery.accountId?.let { id ->
                    FilterChip(
                        selected = true,
                        onClick = { TransactionQueryHelper.selectAccount(viewState.currentQuery, null)?.let(::dispatchQuery) },
                        label = { Text("账户：${TransactionQueryHelper.accountDisplayLabel(id, metadataState.accountNames)} ×") },
                    )
                }
                if (viewState.currentQuery.categoryId.isNotEmpty()) {
                    val catLabel = metadataState.categoryNames[viewState.currentQuery.categoryId] ?: "分类信息暂不可用"
                    FilterChip(
                        selected = true,
                        onClick = { dispatchQuery(viewState.currentQuery.copy(categoryId = "", page = 0)) },
                        label = { Text("分类：$catLabel ×") },
                    )
                }
                if (viewState.currentQuery.tag.isNotEmpty()) {
                    FilterChip(
                        selected = true,
                        onClick = { dispatchQuery(viewState.currentQuery.copy(tag = "", page = 0)) },
                        label = { Text("标签：${viewState.currentQuery.tag} ×") },
                    )
                }
                if (viewState.currentQuery.search.isNotBlank()) {
                    FilterChip(
                        selected = true,
                        onClick = {
                            searchText = ""
                            dispatchQuery(viewState.currentQuery.copy(search = "", page = 0))
                        },
                        label = { Text("搜索：${viewState.currentQuery.search} ×") },
                    )
                }
                TextButton(onClick = {
                    searchText = ""
                    dispatchQuery(TransactionQueryHelper.clearFilters(viewState.currentQuery))
                }) { Text("清除") }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val totalText = if (viewState.total != null) "共 ${viewState.total} 笔" else if (viewState.loading) "加载中…" else "条数暂不可用"
            Text("第 ${viewState.currentQuery.page + 1} 页 · $totalText", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            IconButton(onClick = { dispatchQuery(viewState.currentQuery) }, enabled = !viewState.loading) {
                Icon(Icons.Filled.Refresh, contentDescription = "刷新账单")
            }
            OutlinedButton(
                onClick = { TransactionQueryHelper.changePage(viewState.currentQuery, viewState.currentQuery.page - 1)?.let(::dispatchQuery) },
                enabled = !viewState.loading && viewState.currentQuery.page > 0,
            ) { Text("上一页") }
            Spacer(Modifier.size(4.dp))
            OutlinedButton(
                onClick = { TransactionQueryHelper.changePage(viewState.currentQuery, viewState.currentQuery.page + 1)?.let(::dispatchQuery) },
                enabled = !viewState.loading && viewState.total != null && (viewState.currentQuery.page + 1) * viewState.currentQuery.pageSize < (viewState.total ?: 0),
            ) { Text("下一页") }
        }

        when {
            viewState.loading && viewState.items.isEmpty() -> {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator()
                        Text("正在加载账单", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            viewState.items.isEmpty() && viewState.error != null -> {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("账单暂时无法加载", style = MaterialTheme.typography.titleMedium)
                        Text(viewState.error.orEmpty(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = { dispatchQuery(viewState.currentQuery) }) { Text("重试") }
                    }
                }
            }
            else -> {
                if (viewState.loading) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    if (viewState.items.isNotEmpty()) {
                        Text(
                            "正在更新，当前显示上次结果",
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                if (viewState.error != null) {
                    Text(
                        "更新失败，当前显示上次结果：${viewState.error}",
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                if (viewState.items.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (activeFilterCount > 0 || viewState.currentQuery.search.isNotBlank()) "没有符合条件的账单" else "本月还没有账单", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (activeFilterCount > 0 || viewState.currentQuery.search.isNotBlank()) "试试调整月份或清除筛选条件" else "记录一笔后，这里会显示账单详情",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall,
                            )
                            if (activeFilterCount > 0 || viewState.currentQuery.search.isNotBlank()) {
                                OutlinedButton(onClick = {
                                    searchText = ""
                                    dispatchQuery(TransactionQueryHelper.clearFilters(viewState.currentQuery))
                                }) { Text("清除筛选") }
                            } else {
                                OutlinedButton(onClick = onNew) { Text("开始记账") }
                            }
                        }
                    }
                } else {
                    // Group rows by day label; amounts stay per-row server values.
                    val grouped = viewState.items.groupBy { formatDay(it.optLong("date")) }
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        grouped.forEach { (dayLabel, dayItems) ->
                            item(key = "header-$dayLabel-${dayItems.firstOrNull()?.optString("id")}") {
                                Text(
                                    dayLabel,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 4.dp),
                                )
                            }
                            items(dayItems, key = { it.optString("id") }) { tx ->
                                TransactionCard(
                                    tx = tx,
                                    categoryNames = metadataState.categoryNames,
                                    categoryIcons = metadataState.categoryIcons,
                                    categoryColors = metadataState.categoryColors,
                                    accountNames = metadataState.accountNames,
                                    onOpen = { onOpen(tx.optString("id")) },
                                    onEdit = { onEdit(tx.optString("id")) },
                                    onDelete = { confirmDelete = tx },
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFilters) {
        ModalBottomSheet(
            onDismissRequest = { showFilters = false },
            sheetState = sheetState,
        ) {
            val accountChoices = TransactionQueryHelper.buildAccountChoices(
                accountNames = metadataState.accountNames,
                selectedAccountId = draftAccountFilter,
            )
            val categoryChoices = buildList {
                add("" to "全部")
                if (draftCategoryFilter.isNotEmpty() && metadataState.categoryNames[draftCategoryFilter] == null) {
                    add(draftCategoryFilter to "分类信息暂不可用（保留当前条件）")
                }
                addAll(metadataState.categoryNames.entries.sortedBy { it.value }.map { it.key to it.value })
            }
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("筛选账单", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("选择条件后点“应用”，列表才会更新。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("账户", style = MaterialTheme.typography.titleSmall)
                ListChoice("账户", accountChoices, draftAccountFilter ?: "") { draftAccountFilter = it.ifEmpty { null } }
                Text("分类", style = MaterialTheme.typography.titleSmall)
                ListChoice("分类", categoryChoices, draftCategoryFilter) { draftCategoryFilter = it }
                Text("标签", style = MaterialTheme.typography.titleSmall)
                ListChoice("标签", listOf("" to "全部") + metadataState.tags.sorted().map { it to it }, draftTagFilter) { draftTagFilter = it }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = {
                        draftAccountFilter = null
                        draftCategoryFilter = ""
                        draftTagFilter = ""
                    }) { Text("重置") }
                    Spacer(Modifier.weight(1f))
                    OutlinedButton(onClick = { showFilters = false }) { Text("取消") }
                    Button(onClick = {
                        showFilters = false
                        val newQuery = viewState.currentQuery.copy(
                            accountId = draftAccountFilter,
                            categoryId = draftCategoryFilter,
                            tag = draftTagFilter,
                            page = 0,
                        )
                        dispatchQuery(newQuery)
                    }) { Text("应用") }
                }
            }
        }
    }

    if (confirmDelete != null) {
        val label = confirmDelete!!.optString("note").ifEmpty { "这笔账单" }
        AlertDialog(
            onDismissRequest = { if (!deleting) confirmDelete = null },
            title = { Text("删除$label？") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("删除后可在回收站恢复")
                    deleteError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                Button(enabled = !deleting, onClick = {
                    val id = confirmDelete!!.optString("id")
                    deleteError = null
                    scope.launch {
                        deleting = true
                        try {
                            ledger.removeTransaction(id)
                            confirmDelete = null
                            dispatchQuery(viewState.currentQuery)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: AuthExpiredException) {
                            onAuthExpired()
                        } catch (e: Exception) {
                            deleteError = e.message ?: "删除失败，请重试。"
                        } finally {
                            deleting = false
                        }
                    }
                }) { Text(if (deleting) "删除中…" else "删除") }
            },
            dismissButton = {
                OutlinedButton(enabled = !deleting, onClick = { confirmDelete = null }) { Text("取消") }
            },
        )
    }
}

@Composable
private fun TransactionCard(
    tx: JSONObject,
    categoryNames: Map<String, String>,
    categoryIcons: Map<String, String>,
    categoryColors: Map<String, Long>,
    accountNames: Map<String, String>,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    var menuExpanded by remember(tx.optString("id")) { mutableStateOf(false) }
    val type = tx.optInt("type")
    val refund = tx.optBoolean("isRefund")
    val isIncome = type == 1 || refund
    val sign = if (isIncome) "+" else "−"
    val catId = tx.optString("categoryId")
    val category = categoryNames[catId].orEmpty()
    val note = tx.optString("note").trim()
    val title = note.ifEmpty { category.ifEmpty { "未分类" } }
    val subtitle = listOf(
        if (note.isNotEmpty() && category.isNotEmpty()) category else null,
        accountNames[tx.optString("accountId")].orEmpty().ifEmpty { null },
        formatDay(tx.optLong("date")),
    ).filterNotNull().filter { it.isNotEmpty() }.joinToString(" · ")

    val iconName = categoryIcons[catId]
    val colorVal = categoryThemeColor(iconName, categoryColors[catId])
    val kindLabel = if (refund) "退款" else if (type == 1) "收入" else "支出"

    FinanceCard(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 18.dp,
        contentPadding = 12.dp,
        onClick = onOpen,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            FinanceCategoryIcon(
                iconName = iconName,
                backgroundColor = colorVal,
                size = 40.dp,
                iconSize = 22.dp,
            )
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = LocalWebTokens.current.fg,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalWebTokens.current.muted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = "$sign${formatYuan(tx.optLong("amountCents"))}",
                color = if (isIncome) LocalWebTokens.current.ok else LocalWebTokens.current.danger,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
            )
            Box {
                IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "账单操作", tint = LocalWebTokens.current.muted)
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(
                        text = { Text("编辑") },
                        leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                        onClick = { menuExpanded = false; onEdit() },
                    )
                    DropdownMenuItem(
                        text = { Text("删除") },
                        leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                        onClick = { menuExpanded = false; onDelete() },
                    )
                }
            }
        }
        val txTags = tx.optJSONArray("tags")
        if (refund || (txTags != null && txTags.length() > 0)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, start = 56.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (refund) {
                    Surface(
                        shape = CircleShape,
                        color = LocalWebTokens.current.ok.copy(alpha = 0.15f),
                    ) {
                        Text(
                            kindLabel,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            color = LocalWebTokens.current.ok,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }
                if (txTags != null) {
                    for (i in 0 until txTags.length()) {
                        Surface(
                            shape = CircleShape,
                            color = LocalWebTokens.current.surfaceSoft,
                        ) {
                            Text(
                                "#${txTags.optString(i)}",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = LocalWebTokens.current.muted,
                                maxLines = 1,
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun monthRange(offset: Int): Pair<Long, Long> {
    val cal = Calendar.getInstance()
    cal.set(Calendar.DAY_OF_MONTH, 1)
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    cal.add(Calendar.MONTH, offset)
    val from = cal.timeInMillis
    cal.add(Calendar.MONTH, 1)
    return from to cal.timeInMillis
}

private fun monthLabel(offset: Int): String {
    val cal = Calendar.getInstance()
    cal.add(Calendar.MONTH, offset)
    return "${cal.get(Calendar.YEAR)}年${cal.get(Calendar.MONTH) + 1}月"
}
