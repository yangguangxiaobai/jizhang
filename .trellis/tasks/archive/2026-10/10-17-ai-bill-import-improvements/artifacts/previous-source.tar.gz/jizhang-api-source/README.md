# jizhang

Single-user accounting with a native Kotlin/Compose Android client (also intended for HarmonyOS 4), a Fastify API and SQLite. The production backend is **API-only**. The intended endpoint is `https://jz.yansuu1.xyz`; visiting its root returns JSON 404 rather than a Web page.

The owner's server currently runs the previous Web Docker version. New repository configuration does **not** establish that it has been upgraded. [DEPLOY.md](./DEPLOY.md) covers image delivery, Caddy, existing-data migration and rollback. Server/device acceptance remains part of the active delivery task.

## Features and contracts

See [Android current feature inventory](./clients/android/README.md) for the maintained, source-backed page, field, action, API and known-gap catalogue. The [UI redesign plan](./clients/android/ui-redesign/README.md) describes intended design and is not proof of current implementation.

- Transactions, refunds, accounts, tags, transfers and recycle bin.
- Salary allocations, budget templates, historical cycles and carryover pool.
- Recurring rules, explicit generation, confirmation and ignore.
- Statistics, CSV and WeChat/Alipay portability, consistent SQLite backups.
- AI conversations and confirmation before writes; encrypted provider credentials.
- Personal items, photographs and optional private cutout inference.
- Native navigation, system/light/dark appearance and color presets.

Money is integer cents; timestamps are epoch milliseconds. Server/shared owns all budget/aggregation rules; Android displays responses. `TZ=Asia/Shanghai` governs the deployed calendar. Transfers do not count as spending/income. [USAGE.md](./USAGE.md) is temporarily the legacy feature reference; browser/PWA instructions do not apply to the new deployment.

## Repository

| Path                           | Responsibility                                              |
| ------------------------------ | ----------------------------------------------------------- |
| `clients/android/`             | Kotlin + Compose APK                                        |
| `clients/README.md`            | Client status and validation                                |
| `packages/server/`             | Fastify API, SQLite, auth and maintenance CLI               |
| `packages/shared/`             | Pure accounting/date/portability contracts                  |
| `packages/cutout/`             | Optional private inference worker                           |
| `packages/web/`                | Temporary parity reference, excluded from production images |
| `Dockerfile`                   | Server/shared build, Node 22 non-root runtime               |
| `docker-compose.yml`           | Loopback API, persistent data, opt-in cutout profile        |
| `docker-compose.migration.yml` | Exact existing external data volume                         |
| `docker-compose.bind.yml`      | Existing bind-mount alternative                             |
| `docker-compose.caddy.yml`     | Alternative bridge-network Caddy connection                 |
| `deploy/`                      | Caddy examples and read-only backup comparison              |

Web source removal follows full Android acceptance and useful contract/test migration. Keeping reference code does not re-enable Web hosting. Existing HarmonyOS 5/6 sources remain outside this delivery's expansion scope.

## API development

Node.js >= 22.12 and pnpm 10.12.2 are required. From the root:

```bash
pnpm install --frozen-lockfile
cp .env.example .env
pnpm --filter @jizhang/shared build
pnpm --filter @jizhang/server dev
```

Health is `http://127.0.0.1:8081/api/v1/health`. Copying `.env` does not create a database login: build the server, then run `node packages/server/dist/cli.js set-password` from the root in an interactive terminal. Existing upgrades preserve login. Gitignored `.env` is read locally outside production; Compose injects container settings.

```bash
pnpm --filter @jizhang/shared build
pnpm --filter @jizhang/shared test
pnpm --filter @jizhang/server lint
pnpm --filter @jizhang/server typecheck
pnpm --filter @jizhang/server test
pnpm --filter @jizhang/server build
```

Android builds from `clients/android` using `gradlew.bat :app:assembleDebug :app:lintDebug` (Windows) or `./gradlew` (Linux/macOS). Release signing belongs to the owner; keep keys/secrets outside Git and Docker contexts. APK build success does not establish device usability.

## Docker

For a **new local/disposable instance**, initialize `.env` then:

```bash
docker compose config --quiet
docker compose build jizhang
docker compose up -d --force-recreate jizhang
docker compose exec -it jizhang node packages/server/dist/cli.js set-password
curl -fsS http://127.0.0.1:8081/api/v1/health
```

For the **existing server**, follow [DEPLOY.md](./DEPLOY.md): inspect the original mount, preserve credentials/AI encryption key, verify restored backups, and include the migration/bind overlay on every command. API publishes only `127.0.0.1:8081`; existing Caddy retains 80/443. The supplied inventory shows the `caddy` container uses **host networking**, so it uses loopback and needs no Caddy shared-network overlay. Validate/reload with `docker exec caddy` after confirming its config path. The alternative bridge-network Caddy example uses a shared network and `jizhang-api:8081`. No new proxy/TLS container is created.

Cutout is opt-in: set its URL and use `--profile cutout` on an adequately sized server. It retains a private network, no published ports and resource limits. Ordinary item/photo operations work without inference.

SQLite and historical backups live in `/data`; photos are SQLite BLOBs. Never copy a live database alone: CLI backup produces a WAL-consistent snapshot. Restore requires every writer stopped. Retain protected off-server backups and old image/configuration for schema-compatible rollback.
